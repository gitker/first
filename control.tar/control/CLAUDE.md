
This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project

`remote-control` is a cross-platform single-binary actix-web server that exposes a PTY shell session over an end-to-end-encrypted WebSocket, with a browser SPA frontend served from `static/index.html`. The server binds `0.0.0.0:8080`, clients authenticate with a shared access token, and an integrated reverse proxy client can publish that local HTTP service through a remote proxy server.

## Commands

- `cargo run` — start the server. Reads `config.json` by default; `REMOTE_CONTROL_CONFIG` can point to another config file.
- `cargo build --release` — release build.
- `cargo check` — fast typecheck without producing a binary.
- `cargo test` — run all unit tests (the `#[cfg(test)] mod tests` block at the bottom of `main.rs`).
- `cargo test <name>` — run a single test, e.g. `cargo test encrypted_payload_roundtrip_works`.
- `RUST_LOG=debug cargo run` — verbose logs. `env_logger` is initialized with default filter `info`.

The server requires `static/index.html` to exist at runtime — it is read at request time via `tokio::fs::read_to_string(env!("CARGO_MANIFEST_DIR")/static/index.html)`. The `static/` directory in this tree may be empty; the frontend must be present for `/` to serve anything useful.

The terminal backend is platform-aware: Windows starts `powershell.exe` with a bootstrap script, while macOS/Linux start `$SHELL` or a platform default via `portable-pty`.

Runtime configuration lives in `config.json`. The default file configures the HTTP bind address, browser access token, and reverse proxy client (`47.106.107.148:7000` -> `127.0.0.1:8080`, PSK `your-strong-psk199029`). Environment variables still override config values for one-off runs: `REMOTE_CONTROL_BIND_ADDR`, `REMOTE_CONTROL_ACCESS_TOKEN`, `REMOTE_PROXY_ENABLED`, `REMOTE_PROXY_SERVER_HOST`, `REMOTE_PROXY_SERVER_PORT`, `REMOTE_PROXY_TARGET_HOST`, `REMOTE_PROXY_TARGET_PORT`, `REMOTE_PROXY_PSK`, `REMOTE_PROXY_CONNECT_TIMEOUT`, `REMOTE_PROXY_RETRY_INTERVAL`, `REMOTE_PROXY_HEARTBEAT_INTERVAL`, and `REMOTE_PROXY_HEARTBEAT_TIMEOUT`.

## Architecture

Core source files: `src/main.rs` contains HTTP routing, WS handling, session lifecycle, crypto, and PTY pumping; `src/terminal.rs` defines the browser wire-format `Serialize`/`Deserialize` structs; `src/reverse_proxy.rs` implements the reverse TCP proxy client protocol from `reverse_proxy.py`.

### Wire protocol and crypto

Each WS connection runs its own AES-256-GCM cipher derived per-connection. The handshake is:

1. Server generates a 16-byte random salt, derives a key via `HKDF-SHA256(access_token, salt, info="remote-control-v1")`, and sends the salt to the client in a **plaintext** `hello` frame (`ServerHello`). This is the only unencrypted frame after connection setup.
2. Client must reply with an encrypted `auth` payload (`ClientPayload` with `type: "auth"`). Successful decrypt = proof of access token. Any decrypt failure closes the socket.
3. All subsequent frames in both directions are JSON `EncryptedEnvelope { nonce, ciphertext }` where `nonce` is a fresh 12-byte random per message and `ciphertext` is base64 of the AES-GCM ciphertext over a `serde_json`-serialized `ClientPayload`/`ServerPayload`.

`encrypt_payload` / `decrypt_payload` in `main.rs` are the choke points; the `encrypted_payload_roundtrip_works` test exercises them.

### Session model

`TerminalSession` owns one PTY pair, the spawned child process, and the I/O channels. Construction (`create_terminal_session`) spawns three concurrent contexts that you must keep in mind when changing anything in this area:

- **Output thread** (`std::thread::spawn` + `pump_pty_output`): blocking reads from PTY master, pushes each chunk into the session's `OutputHistory` and broadcasts a `SessionEvent::Output`.
- **Input thread** (`std::thread::spawn`): blocking `input_rx.blocking_recv()` from a `tokio::sync::mpsc` channel, writes to the PTY master writer. The async WS handler sends into this channel via `terminal_session.send_input(...).await`.
- **Exit watcher thread** (`spawn_session_exit_watcher`): blocks on `child.wait()`, then marks the session closed and removes it from the global map.

Output is stored in `OutputHistory` as a `VecDeque<BufferedOutput>` of base64-encoded chunks, each tagged with a monotonically increasing `seq`. The buffer is capped at `MAX_OUTPUT_HISTORY_BYTES = 512 KiB` (encoded size); old entries are evicted FIFO. A `tokio::sync::broadcast::Sender<SessionEvent>` fans output out to whichever WS handler is currently attached.

### Reconnect and resume

A client that gets disconnected can reconnect and present `session_id` + `resume_token` + `last_output_seq` in its `auth` payload. The server looks up the session, verifies the token, replays `backlog_since(last_output_seq)`, and continues.

Only one attachment is active at a time per session: `current_attachment_id` (an `AtomicU64`) is bumped on attach. Every send-loop check goes through `is_current_attachment(attachment_id)`, so a new attachment effectively evicts the previous WS handler from the session.

When a WS handler exits without an explicit `disconnect` message, it calls `mark_detached` (recording `last_detached_at`) instead of killing the session. The session lives for `RESUME_TTL = 30 minutes` after detach. A background `run_session_reaper` task scans every `SESSION_REAPER_INTERVAL = 60 seconds` and shuts down sessions that exceed the TTL while detached. An explicit client `disconnect` message removes and shuts down the session immediately.

### Terminal shell bootstrap

On Windows, `POWERSHELL_BOOTSTRAP` (a constant raw string in `main.rs`) is passed to `powershell.exe -NoLogo -NoProfile -NoExit -Command`. It does two things:

1. Forces UTF-8 (no BOM) for `[Console]::InputEncoding`, `OutputEncoding`, and `$OutputEncoding`.
2. Defines `Set-RemoteLocation` and aliases `cd` / `chdir` to it. This wrapper detects `file://` URIs in the path argument and converts them to local paths via `[System.Uri]`. Without this, dragging a Windows file URL into the terminal would break `cd`.

`normalize_path` in `main.rs` does the same `file://`-to-local-path conversion server-side for the initial `cwd` from the `auth` payload. If no valid directory is provided, `resolve_initial_cwd` chooses a platform default. Tests for this live in the bottom of `main.rs`.

### Client message types

`ClientPayload.r#type` is one of: `auth` (only valid as first message), `input` (data → PTY stdin), `resize` (cols/rows → PTY resize, dispatched via `tokio::task::spawn_blocking`), `ping` (server replies with encrypted `pong`), `disconnect` (terminate session). Any unknown type is silently ignored; any decrypt failure breaks the connection.
