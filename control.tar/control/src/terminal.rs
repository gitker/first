use serde::{Deserialize, Serialize};

#[derive(Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct DisplayCell {
    #[serde(rename = "c")]
    pub ch: String,
    #[serde(rename = "f")]
    #[serde(skip_serializing_if = "Option::is_none")]
    pub fg: Option<[u8; 3]>,
    #[serde(rename = "b")]
    #[serde(skip_serializing_if = "Option::is_none")]
    pub bg: Option<[u8; 3]>,
    #[serde(rename = "w")]
    #[serde(skip_serializing_if = "std::ops::Not::not")]
    pub bold: bool,
    #[serde(rename = "i")]
    #[serde(skip_serializing_if = "std::ops::Not::not")]
    pub inverse: bool,
}

#[derive(Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct DisplaySpan {
    #[serde(rename = "x")]
    pub start: u16,
    #[serde(rename = "n")]
    pub len: u16,
    #[serde(rename = "f")]
    #[serde(skip_serializing_if = "Option::is_none")]
    pub fg: Option<[u8; 3]>,
    #[serde(rename = "b")]
    #[serde(skip_serializing_if = "Option::is_none")]
    pub bg: Option<[u8; 3]>,
    #[serde(rename = "w")]
    #[serde(skip_serializing_if = "std::ops::Not::not")]
    pub bold: bool,
    #[serde(rename = "i")]
    #[serde(skip_serializing_if = "std::ops::Not::not")]
    pub inverse: bool,
}

#[derive(Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct DisplayRow {
    #[serde(rename = "t")]
    pub text: String,
    #[serde(rename = "s")]
    #[serde(skip_serializing_if = "Vec::is_empty")]
    pub spans: Vec<DisplaySpan>,
}

#[derive(Clone, Serialize, Deserialize)]
pub struct DisplayRowPatch {
    #[serde(rename = "y")]
    pub row: u16,
    #[serde(flatten)]
    pub data: DisplayRow,
}

#[derive(Clone, Serialize, Deserialize)]
pub struct DisplayDelta {
    pub cols: u16,
    pub rows: u16,
    #[serde(skip_serializing_if = "std::ops::Not::not")]
    pub full: bool,
    #[serde(rename = "h")]
    #[serde(skip_serializing_if = "Option::is_none")]
    pub history: Option<Vec<String>>,
    #[serde(rename = "r")]
    pub screen_rows: Vec<DisplayRowPatch>,
    pub cursor_col: u16,
    pub cursor_row: u16,
    pub cursor_visible: bool,
    pub alternate_screen: bool,
}

#[derive(Clone, Serialize, Deserialize)]
pub struct DisplaySnapshot {
    pub cols: u16,
    pub rows: u16,
    pub history: Vec<String>,
    pub screen: Vec<String>,
    pub history_cells: Vec<Vec<DisplayCell>>,
    pub screen_cells: Vec<Vec<DisplayCell>>,
    pub screen_rows: Vec<DisplayRow>,
    pub cursor_col: u16,
    pub cursor_row: u16,
    pub cursor_visible: bool,
    pub alternate_screen: bool,
}

#[derive(Serialize)]
pub struct ServerHello {
    pub r#type: &'static str,
    pub salt: String,
}

#[derive(Serialize, Deserialize)]
pub struct EncryptedEnvelope {
    pub nonce: String,
    pub ciphertext: String,
}

#[derive(Serialize, Deserialize)]
pub struct ClientPayload {
    pub r#type: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub data: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub cwd: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub cols: Option<u16>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub rows: Option<u16>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub session_id: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub resume_token: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub last_output_seq: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub history_limit: Option<usize>,
}

#[derive(Serialize, Deserialize)]
pub struct ServerPayload {
    pub r#type: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub data: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub data_base64: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub cwd: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub message: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub session_id: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub resume_token: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub resumed: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub output_seq: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub alternate_screen: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub mouse_tracking: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub mouse_sgr: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub alternate_scroll: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub display: Option<DisplaySnapshot>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub display_delta: Option<DisplayDelta>,
}

impl ServerPayload {
    pub fn ready(
        cwd: String,
        session_id: String,
        resume_token: String,
        resumed: bool,
        alternate_screen: bool,
        mouse_tracking: bool,
        mouse_sgr: bool,
        alternate_scroll: bool,
        display: DisplaySnapshot,
    ) -> Self {
        Self {
            r#type: "ready".to_string(),
            data: None,
            data_base64: None,
            cwd: Some(cwd),
            message: None,
            session_id: Some(session_id),
            resume_token: Some(resume_token),
            resumed: Some(resumed),
            output_seq: None,
            alternate_screen: Some(alternate_screen),
            mouse_tracking: Some(mouse_tracking),
            mouse_sgr: Some(mouse_sgr),
            alternate_scroll: Some(alternate_scroll),
            display: Some(display),
            display_delta: None,
        }
    }

    pub fn error(message: String) -> Self {
        Self {
            r#type: "error".to_string(),
            data: None,
            data_base64: None,
            cwd: None,
            message: Some(message),
            session_id: None,
            resume_token: None,
            resumed: None,
            output_seq: None,
            alternate_screen: None,
            mouse_tracking: None,
            mouse_sgr: None,
            alternate_scroll: None,
            display: None,
            display_delta: None,
        }
    }

    pub fn pong() -> Self {
        Self {
            r#type: "pong".to_string(),
            data: None,
            data_base64: None,
            cwd: None,
            message: None,
            session_id: None,
            resume_token: None,
            resumed: None,
            output_seq: None,
            alternate_screen: None,
            mouse_tracking: None,
            mouse_sgr: None,
            alternate_scroll: None,
            display: None,
            display_delta: None,
        }
    }

    pub fn terminal_mode(
        alternate_screen: bool,
        mouse_tracking: bool,
        mouse_sgr: bool,
        alternate_scroll: bool,
    ) -> Self {
        Self {
            r#type: "terminal_mode".to_string(),
            data: None,
            data_base64: None,
            cwd: None,
            message: None,
            session_id: None,
            resume_token: None,
            resumed: None,
            output_seq: None,
            alternate_screen: Some(alternate_screen),
            mouse_tracking: Some(mouse_tracking),
            mouse_sgr: Some(mouse_sgr),
            alternate_scroll: Some(alternate_scroll),
            display: None,
            display_delta: None,
        }
    }

    pub fn display_delta(display_delta: DisplayDelta, output_seq: Option<u64>) -> Self {
        Self {
            r#type: "display_delta".to_string(),
            data: None,
            data_base64: None,
            cwd: None,
            message: None,
            session_id: None,
            resume_token: None,
            resumed: None,
            output_seq,
            alternate_screen: Some(display_delta.alternate_screen),
            mouse_tracking: None,
            mouse_sgr: None,
            alternate_scroll: None,
            display: None,
            display_delta: Some(display_delta),
        }
    }
}
