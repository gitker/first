use crate::terminal::{DisplayRow, DisplaySnapshot, DisplaySpan};
use std::collections::VecDeque;
use unicode_width::UnicodeWidthChar;

#[allow(dead_code)]
const DEFAULT_DISPLAY_HISTORY_LIMIT: usize = 5000;

#[derive(Clone)]
struct Cell {
    ch: char,
    style: Style,
}

impl Default for Cell {
    fn default() -> Self {
        Self {
            ch: ' ',
            style: Style::default(),
        }
    }
}

#[derive(Clone, Copy, Default, PartialEq, Eq)]
struct Style {
    fg: Option<[u8; 3]>,
    bg: Option<[u8; 3]>,
    bold: bool,
    inverse: bool,
}

#[derive(Clone)]
struct Cursor {
    row: usize,
    col: usize,
}

pub struct DisplayState {
    parser: AnsiParser,
    terminal: TerminalDisplay,
}

impl DisplayState {
    pub fn new(cols: u16, rows: u16, history_limit: usize) -> Self {
        Self {
            parser: AnsiParser::default(),
            terminal: TerminalDisplay::new(cols, rows, history_limit),
        }
    }

    pub fn process(&mut self, bytes: &[u8]) -> DisplaySnapshot {
        self.parser.advance(&mut self.terminal, bytes);
        self.snapshot()
    }

    pub fn resize(&mut self, cols: u16, rows: u16) -> DisplaySnapshot {
        self.terminal.resize(cols, rows);
        self.snapshot()
    }

    pub fn snapshot(&self) -> DisplaySnapshot {
        self.terminal.snapshot()
    }
}

struct TerminalDisplay {
    cols: usize,
    rows: usize,
    screen: Vec<Vec<Cell>>,
    scrollback: VecDeque<Vec<Cell>>,
    history_limit: usize,
    cursor: Cursor,
    saved_cursor: Cursor,
    scroll_top: usize,
    scroll_bottom: usize,
    alternate_screen: bool,
    normal_screen: Vec<Vec<Cell>>,
    normal_cursor: Cursor,
    current_style: Style,
    mouse_x10: bool,
    mouse_normal: bool,
    mouse_button: bool,
    mouse_any: bool,
    mouse_sgr: bool,
    autowrap: bool,
    cursor_visible: bool,
}

impl TerminalDisplay {
    fn new(cols: u16, rows: u16, history_limit: usize) -> Self {
        let cols = cols.max(1) as usize;
        let rows = rows.max(1) as usize;
        Self {
            cols,
            rows,
            screen: blank_screen(cols, rows),
            scrollback: VecDeque::new(),
            history_limit: history_limit.max(100),
            cursor: Cursor { row: 0, col: 0 },
            saved_cursor: Cursor { row: 0, col: 0 },
            scroll_top: 0,
            scroll_bottom: rows - 1,
            alternate_screen: false,
            normal_screen: blank_screen(cols, rows),
            normal_cursor: Cursor { row: 0, col: 0 },
            current_style: Style::default(),
            mouse_x10: false,
            mouse_normal: false,
            mouse_button: false,
            mouse_any: false,
            mouse_sgr: false,
            autowrap: true,
            cursor_visible: true,
        }
    }

    fn resize(&mut self, cols: u16, rows: u16) {
        let cols = cols.max(1) as usize;
        let rows = rows.max(1) as usize;
        resize_screen(&mut self.screen, cols, rows);
        resize_screen(&mut self.normal_screen, cols, rows);
        self.cols = cols;
        self.rows = rows;
        self.cursor.row = self.cursor.row.min(rows - 1);
        self.cursor.col = self.cursor.col.min(cols - 1);
        self.saved_cursor.row = self.saved_cursor.row.min(rows - 1);
        self.saved_cursor.col = self.saved_cursor.col.min(cols - 1);
        self.normal_cursor.row = self.normal_cursor.row.min(rows - 1);
        self.normal_cursor.col = self.normal_cursor.col.min(cols - 1);
        self.scroll_top = 0;
        self.scroll_bottom = rows - 1;
    }

    fn snapshot(&self) -> DisplaySnapshot {
        let history_skip = self
            .scrollback
            .len()
            .saturating_sub(self.history_limit);

        DisplaySnapshot {
            cols: self.cols as u16,
            rows: self.rows as u16,
            history: if self.alternate_screen {
                Vec::new()
            } else {
                self.scrollback
                    .iter()
                    .skip(history_skip)
                    .map(|line| line_to_trimmed_string(line))
                    .collect()
            },
            screen: self.screen.iter().map(line_to_trimmed_string).collect(),
            history_cells: Vec::new(),
            screen_cells: Vec::new(),
            screen_rows: self
                .screen
                .iter()
                .map(|line| line_to_display_row(line))
                .collect(),
            cursor_col: self.cursor.col.min(self.cols - 1) as u16,
            cursor_row: self.cursor.row.min(self.rows - 1) as u16,
            cursor_visible: self.cursor_visible,
            alternate_screen: self.alternate_screen,
        }
    }

    fn print(&mut self, ch: char) {
        if ch == '\u{0}' {
            return;
        }

        let width = UnicodeWidthChar::width(ch).unwrap_or(1);
        if width == 0 {
            return;
        }

        if self.cursor.col >= self.cols {
            if self.autowrap {
                self.carriage_return();
                self.line_feed();
            } else {
                self.cursor.col = self.cols - 1;
            }
        }

        if width > 1 && self.cursor.col + width > self.cols {
            if self.autowrap {
                self.carriage_return();
                self.line_feed();
            } else if width <= self.cols {
                self.cursor.col = self.cols - width;
            } else {
                return;
            }
        }

        self.screen[self.cursor.row][self.cursor.col] = Cell {
            ch,
            style: self.current_style,
        };
        for offset in 1..width.min(self.cols - self.cursor.col) {
            self.screen[self.cursor.row][self.cursor.col + offset] = Cell {
                ch: ' ',
                style: self.current_style,
            };
        }
        self.cursor.col += width;
        if self.cursor.col >= self.cols {
            self.cursor.col = self.cols;
        }
    }

    fn execute(&mut self, byte: u8) {
        match byte {
            b'\n' | 0x0b | 0x0c => self.line_feed(),
            b'\r' => self.carriage_return(),
            b'\x08' => self.cursor.col = self.cursor.col.saturating_sub(1),
            b'\t' => {
                self.cursor.col = ((self.cursor.col / 8) + 1)
                    .saturating_mul(8)
                    .min(self.cols - 1)
            }
            _ => {}
        }
    }

    fn esc_dispatch(&mut self, byte: u8) {
        match byte {
            b'7' => self.saved_cursor = self.cursor.clone(),
            b'8' => self.restore_cursor(),
            b'D' => self.line_feed(),
            b'E' => {
                self.line_feed();
                self.carriage_return();
            }
            b'M' => self.reverse_index(),
            b'c' => self.reset(),
            _ => {}
        }
    }

    fn csi_dispatch(&mut self, private: bool, params: &[i32], action: u8) {
        if private && (action == b'h' || action == b'l') {
            self.set_private_modes(params, action == b'h');
            return;
        }

        match action {
            b'A' => self.cursor.row = self.cursor.row.saturating_sub(param(params, 0, 1) as usize),
            b'B' => {
                self.cursor.row =
                    (self.cursor.row + param(params, 0, 1) as usize).min(self.rows - 1)
            }
            b'C' => {
                self.cursor.col =
                    (self.cursor.col + param(params, 0, 1) as usize).min(self.cols - 1)
            }
            b'D' => self.cursor.col = self.cursor.col.saturating_sub(param(params, 0, 1) as usize),
            b'E' => {
                self.cursor.row =
                    (self.cursor.row + param(params, 0, 1) as usize).min(self.rows - 1);
                self.cursor.col = 0;
            }
            b'F' => {
                self.cursor.row = self.cursor.row.saturating_sub(param(params, 0, 1) as usize);
                self.cursor.col = 0;
            }
            b'G' | b'`' => self.cursor.col = one_based(params, 0).min(self.cols - 1),
            b'd' => self.cursor.row = one_based(params, 0).min(self.rows - 1),
            b'H' | b'f' => {
                self.cursor.row = one_based(params, 0).min(self.rows - 1);
                self.cursor.col = one_based(params, 1).min(self.cols - 1);
            }
            b'J' => self.erase_display(param(params, 0, 0)),
            b'K' => self.erase_line(param(params, 0, 0)),
            b'm' => self.set_graphic_rendition(params),
            b'L' => self.insert_lines(param(params, 0, 1) as usize),
            b'M' => self.delete_lines(param(params, 0, 1) as usize),
            b'P' => self.delete_chars(param(params, 0, 1) as usize),
            b'X' => self.erase_chars(param(params, 0, 1) as usize),
            b'@' => self.insert_chars(param(params, 0, 1) as usize),
            b'S' => self.scroll_up(param(params, 0, 1) as usize),
            b'T' => self.scroll_down(param(params, 0, 1) as usize),
            b'r' => self.set_scroll_region(params),
            b's' => self.saved_cursor = self.cursor.clone(),
            b'u' => self.restore_cursor(),
            _ => {}
        }
    }

    fn reset(&mut self) {
        self.screen = blank_screen(self.cols, self.rows);
        self.scrollback.clear();
        self.cursor = Cursor { row: 0, col: 0 };
        self.saved_cursor = self.cursor.clone();
        self.scroll_top = 0;
        self.scroll_bottom = self.rows - 1;
        self.alternate_screen = false;
        self.mouse_x10 = false;
        self.mouse_normal = false;
        self.mouse_button = false;
        self.mouse_any = false;
        self.mouse_sgr = false;
        self.autowrap = true;
        self.cursor_visible = true;
        self.current_style = Style::default();
    }

    fn restore_cursor(&mut self) {
        self.cursor.row = self.saved_cursor.row.min(self.rows - 1);
        self.cursor.col = self.saved_cursor.col.min(self.cols - 1);
    }

    fn carriage_return(&mut self) {
        self.cursor.col = 0;
    }

    fn line_feed(&mut self) {
        if self.cursor.row == self.scroll_bottom {
            self.scroll_up(1);
        } else {
            self.cursor.row = (self.cursor.row + 1).min(self.rows - 1);
        }
    }

    fn reverse_index(&mut self) {
        if self.cursor.row == self.scroll_top {
            self.scroll_down(1);
        } else {
            self.cursor.row = self.cursor.row.saturating_sub(1);
        }
    }

    fn scroll_up(&mut self, count: usize) {
        for _ in 0..count.max(1) {
            let removed = self.screen.remove(self.scroll_top);
            self.screen
                .insert(self.scroll_bottom, blank_line(self.cols));
            if !self.alternate_screen && self.scroll_top == 0 && self.scroll_bottom == self.rows - 1
            {
                self.push_history(trim_cells(&removed));
            }
        }
    }

    fn scroll_down(&mut self, count: usize) {
        for _ in 0..count.max(1) {
            self.screen.remove(self.scroll_bottom);
            self.screen.insert(self.scroll_top, blank_line(self.cols));
        }
    }

    fn push_history(&mut self, line: Vec<Cell>) {
        self.scrollback.push_back(line);
        while self.scrollback.len() > self.history_limit {
            self.scrollback.pop_front();
        }
    }

    fn erase_display(&mut self, mode: i32) {
        match mode {
            0 => {
                self.erase_line_range(self.cursor.row, self.cursor.col, self.cols);
                for row in self.cursor.row + 1..self.rows {
                    self.screen[row] = blank_line(self.cols);
                }
            }
            1 => {
                for row in 0..self.cursor.row {
                    self.screen[row] = blank_line(self.cols);
                }
                self.erase_line_range(self.cursor.row, 0, self.cursor.col + 1);
            }
            2 => {
                for row in 0..self.rows {
                    self.screen[row] = blank_line(self.cols);
                }
            }
            3 => self.scrollback.clear(),
            _ => {}
        }
    }

    fn erase_line(&mut self, mode: i32) {
        match mode {
            0 => self.erase_line_range(self.cursor.row, self.cursor.col, self.cols),
            1 => self.erase_line_range(self.cursor.row, 0, self.cursor.col + 1),
            2 => self.screen[self.cursor.row] = blank_line(self.cols),
            _ => {}
        }
    }

    fn erase_line_range(&mut self, row: usize, start: usize, end: usize) {
        let end = end.min(self.cols);
        for col in start.min(self.cols)..end {
            self.screen[row][col] = Cell::default();
        }
    }

    fn insert_lines(&mut self, count: usize) {
        if self.cursor.row < self.scroll_top || self.cursor.row > self.scroll_bottom {
            return;
        }
        for _ in 0..count.max(1) {
            self.screen.insert(self.cursor.row, blank_line(self.cols));
            self.screen.remove(self.scroll_bottom + 1);
        }
    }

    fn delete_lines(&mut self, count: usize) {
        if self.cursor.row < self.scroll_top || self.cursor.row > self.scroll_bottom {
            return;
        }
        for _ in 0..count.max(1) {
            self.screen.remove(self.cursor.row);
            self.screen
                .insert(self.scroll_bottom, blank_line(self.cols));
        }
    }

    fn insert_chars(&mut self, count: usize) {
        let count = count.max(1).min(self.cols - self.cursor.col);
        let row = &mut self.screen[self.cursor.row];
        for _ in 0..count {
            row.insert(self.cursor.col, Cell::default());
            row.pop();
        }
    }

    fn delete_chars(&mut self, count: usize) {
        let count = count.max(1).min(self.cols - self.cursor.col);
        let row = &mut self.screen[self.cursor.row];
        for _ in 0..count {
            row.remove(self.cursor.col);
            row.push(Cell::default());
        }
    }

    fn erase_chars(&mut self, count: usize) {
        let end = (self.cursor.col + count.max(1)).min(self.cols);
        for col in self.cursor.col..end {
            self.screen[self.cursor.row][col] = Cell::default();
        }
    }

    fn set_scroll_region(&mut self, params: &[i32]) {
        let top = one_based(params, 0);
        let bottom = if params.len() >= 2 && params[1] > 0 {
            (params[1] as usize).saturating_sub(1)
        } else {
            self.rows - 1
        };

        if top < bottom && bottom < self.rows {
            self.scroll_top = top;
            self.scroll_bottom = bottom;
            self.cursor = Cursor { row: 0, col: 0 };
        }
    }

    fn set_private_modes(&mut self, params: &[i32], enabled: bool) {
        for mode in params {
            match *mode {
                47 | 1047 | 1049 => self.set_alternate_screen(enabled),
                9 => self.mouse_x10 = enabled,
                1000 => self.mouse_normal = enabled,
                1002 => self.mouse_button = enabled,
                1003 => self.mouse_any = enabled,
                1006 => self.mouse_sgr = enabled,
                7 => self.autowrap = enabled,
                25 => self.cursor_visible = enabled,
                _ => {}
            }
        }
    }

    fn set_graphic_rendition(&mut self, params: &[i32]) {
        let params = if params.is_empty() { &[0][..] } else { params };
        let mut index = 0;

        while index < params.len() {
            match params[index] {
                0 => self.current_style = Style::default(),
                1 => self.current_style.bold = true,
                2 => self.current_style.bold = false,
                7 => self.current_style.inverse = true,
                22 => self.current_style.bold = false,
                27 => self.current_style.inverse = false,
                30..=37 => {
                    self.current_style.fg = Some(ansi_color((params[index] - 30) as u8, false));
                }
                39 => self.current_style.fg = None,
                40..=47 => {
                    self.current_style.bg = Some(ansi_color((params[index] - 40) as u8, false));
                }
                49 => self.current_style.bg = None,
                90..=97 => {
                    self.current_style.fg = Some(ansi_color((params[index] - 90) as u8, true));
                }
                100..=107 => {
                    self.current_style.bg = Some(ansi_color((params[index] - 100) as u8, true));
                }
                38 | 48 => {
                    let is_fg = params[index] == 38;
                    if let Some((color, consumed)) = extended_color(params, index + 1) {
                        if is_fg {
                            self.current_style.fg = Some(color);
                        } else {
                            self.current_style.bg = Some(color);
                        }
                        index += consumed;
                    }
                }
                _ => {}
            }

            index += 1;
        }
    }

    fn set_alternate_screen(&mut self, enabled: bool) {
        if enabled == self.alternate_screen {
            return;
        }

        if enabled {
            self.normal_screen = self.screen.clone();
            self.normal_cursor = self.cursor.clone();
            self.screen = blank_screen(self.cols, self.rows);
            self.cursor = Cursor { row: 0, col: 0 };
        } else {
            self.screen = self.normal_screen.clone();
            self.cursor = self.normal_cursor.clone();
        }

        self.alternate_screen = enabled;
        self.scroll_top = 0;
        self.scroll_bottom = self.rows - 1;
    }
}

#[derive(Default)]
struct AnsiParser {
    state: ParserState,
    csi: Vec<u8>,
    utf8: Vec<u8>,
}

#[derive(Default)]
enum ParserState {
    #[default]
    Ground,
    Escape,
    EscapeIntermediate,
    Csi,
    Osc,
    OscEscape,
}

impl AnsiParser {
    fn advance(&mut self, terminal: &mut TerminalDisplay, bytes: &[u8]) {
        for &byte in bytes {
            match self.state {
                ParserState::Ground => self.ground(terminal, byte),
                ParserState::Escape => self.escape(terminal, byte),
                ParserState::EscapeIntermediate => self.escape_intermediate(byte),
                ParserState::Csi => self.csi(terminal, byte),
                ParserState::Osc => self.osc(byte),
                ParserState::OscEscape => self.osc_escape(byte),
            }
        }
    }

    fn ground(&mut self, terminal: &mut TerminalDisplay, byte: u8) {
        match byte {
            0x1b => {
                self.flush_utf8(terminal);
                self.state = ParserState::Escape;
            }
            b'\n' | b'\r' | b'\t' | b'\x08' | 0x0b | 0x0c => {
                self.flush_utf8(terminal);
                terminal.execute(byte);
            }
            0x00..=0x1f | 0x7f => {}
            _ => self.push_utf8(terminal, byte),
        }
    }

    fn escape(&mut self, terminal: &mut TerminalDisplay, byte: u8) {
        match byte {
            b'[' => {
                self.csi.clear();
                self.state = ParserState::Csi;
            }
            b']' => self.state = ParserState::Osc,
            b'P' | b'X' | b'^' | b'_' => self.state = ParserState::Osc,
            b'(' | b')' | b'*' | b'+' | b'-' | b'.' | b'/' | b'%' | b'#' => {
                self.state = ParserState::EscapeIntermediate;
            }
            0x1b => self.state = ParserState::Escape,
            _ => {
                terminal.esc_dispatch(byte);
                self.state = ParserState::Ground;
            }
        }
    }

    fn escape_intermediate(&mut self, byte: u8) {
        self.state = if byte == 0x1b {
            ParserState::Escape
        } else {
            ParserState::Ground
        };
    }

    fn csi(&mut self, terminal: &mut TerminalDisplay, byte: u8) {
        if (0x40..=0x7e).contains(&byte) {
            let (private, params) = parse_csi_params(&self.csi);
            terminal.csi_dispatch(private, &params, byte);
            self.state = ParserState::Ground;
            self.csi.clear();
        } else if self.csi.len() < 256 {
            self.csi.push(byte);
        } else {
            self.state = ParserState::Ground;
            self.csi.clear();
        }
    }

    fn osc(&mut self, byte: u8) {
        match byte {
            0x07 => self.state = ParserState::Ground,
            0x1b => self.state = ParserState::OscEscape,
            _ => {}
        }
    }

    fn osc_escape(&mut self, byte: u8) {
        self.state = if byte == b'\\' {
            ParserState::Ground
        } else {
            ParserState::Osc
        };
    }

    fn push_utf8(&mut self, terminal: &mut TerminalDisplay, byte: u8) {
        self.utf8.push(byte);
        match std::str::from_utf8(&self.utf8) {
            Ok(text) => {
                for ch in text.chars() {
                    terminal.print(ch);
                }
                self.utf8.clear();
            }
            Err(error) if error.error_len().is_some() || self.utf8.len() >= 4 => {
                terminal.print('\u{fffd}');
                self.utf8.clear();
            }
            Err(_) => {}
        }
    }

    fn flush_utf8(&mut self, terminal: &mut TerminalDisplay) {
        if self.utf8.is_empty() {
            return;
        }

        if let Ok(text) = std::str::from_utf8(&self.utf8) {
            for ch in text.chars() {
                terminal.print(ch);
            }
        }
        self.utf8.clear();
    }
}

fn parse_csi_params(raw: &[u8]) -> (bool, Vec<i32>) {
    let mut raw = raw;
    let private = raw.first() == Some(&b'?');
    if private {
        raw = &raw[1..];
    }

    let text = std::str::from_utf8(raw).unwrap_or("");
    let params = text
        .split(';')
        .map(|part| {
            part.split(':')
                .next()
                .unwrap_or("")
                .parse::<i32>()
                .unwrap_or(0)
        })
        .collect::<Vec<_>>();

    (private, params)
}

fn param(params: &[i32], index: usize, default: i32) -> i32 {
    params
        .get(index)
        .copied()
        .filter(|value| *value > 0)
        .unwrap_or(default)
}

fn one_based(params: &[i32], index: usize) -> usize {
    param(params, index, 1).saturating_sub(1) as usize
}

fn blank_screen(cols: usize, rows: usize) -> Vec<Vec<Cell>> {
    (0..rows).map(|_| blank_line(cols)).collect()
}

fn blank_line(cols: usize) -> Vec<Cell> {
    vec![Cell::default(); cols]
}

fn resize_screen(screen: &mut Vec<Vec<Cell>>, cols: usize, rows: usize) {
    for row in screen.iter_mut() {
        row.resize(cols, Cell::default());
    }
    while screen.len() < rows {
        screen.push(blank_line(cols));
    }
    screen.truncate(rows);
}

fn line_to_string(line: &Vec<Cell>) -> String {
    line.iter().map(|cell| cell.ch).collect()
}

fn line_to_trimmed_string(line: &Vec<Cell>) -> String {
    line_to_string(line).trim_end().to_string()
}

fn trim_cells(line: &[Cell]) -> Vec<Cell> {
    let end = line
        .iter()
        .rposition(|cell| cell.ch != ' ' || cell.style.bg.is_some())
        .map(|index| index + 1)
        .unwrap_or(0);
    line[..end].to_vec()
}

fn line_to_display_row(line: &Vec<Cell>) -> DisplayRow {
    let trimmed = trim_cells(line);
    let text = trimmed.iter().map(|cell| cell.ch).collect::<String>();
    let mut spans = Vec::new();
    let mut index = 0;

    while index < trimmed.len() {
        let style = trimmed[index].style;
        if style == Style::default() {
            index += 1;
            continue;
        }

        let start = index;
        index += 1;
        while index < trimmed.len() && trimmed[index].style == style {
            index += 1;
        }

        let (fg, bg) = if style.inverse {
            (style.bg, style.fg)
        } else {
            (style.fg, style.bg)
        };

        spans.push(DisplaySpan {
            start: start as u16,
            len: (index - start) as u16,
            fg,
            bg,
            bold: style.bold,
            inverse: style.inverse,
        });
    }

    DisplayRow { text, spans }
}

fn ansi_color(index: u8, bright: bool) -> [u8; 3] {
    const NORMAL: [[u8; 3]; 8] = [
        [26, 29, 36],
        [239, 68, 68],
        [74, 222, 128],
        [250, 204, 21],
        [96, 165, 250],
        [192, 132, 252],
        [34, 211, 238],
        [230, 230, 230],
    ];
    const BRIGHT: [[u8; 3]; 8] = [
        [75, 85, 99],
        [248, 113, 113],
        [134, 239, 172],
        [253, 224, 71],
        [147, 197, 253],
        [216, 180, 254],
        [103, 232, 249],
        [243, 244, 246],
    ];

    if bright {
        BRIGHT[index as usize]
    } else {
        NORMAL[index as usize]
    }
}

fn extended_color(params: &[i32], start: usize) -> Option<([u8; 3], usize)> {
    match params.get(start).copied()? {
        5 => {
            let color = color_256(params.get(start + 1).copied()? as u8);
            Some((color, 2))
        }
        2 => {
            let r = params.get(start + 1).copied()?.clamp(0, 255) as u8;
            let g = params.get(start + 2).copied()?.clamp(0, 255) as u8;
            let b = params.get(start + 3).copied()?.clamp(0, 255) as u8;
            Some(([r, g, b], 4))
        }
        _ => None,
    }
}

fn color_256(index: u8) -> [u8; 3] {
    if index < 16 {
        return ansi_color(index % 8, index >= 8);
    }

    if index <= 231 {
        let n = index - 16;
        let r = n / 36;
        let g = (n % 36) / 6;
        let b = n % 6;
        return [cube_component(r), cube_component(g), cube_component(b)];
    }

    let gray = 8 + (index - 232) * 10;
    [gray, gray, gray]
}

fn cube_component(value: u8) -> u8 {
    if value == 0 {
        0
    } else {
        55 + value * 40
    }
}

#[cfg(test)]
mod tests {
    use super::DisplayState;
    use super::DEFAULT_DISPLAY_HISTORY_LIMIT;

    #[test]
    fn captures_basic_output_and_scrollback() {
        let mut display = DisplayState::new(5, 2, DEFAULT_DISPLAY_HISTORY_LIMIT);
        let snapshot = display.process(b"hello\r\nworld\r\nnext");

        assert_eq!(snapshot.history, vec!["hello"]);
        assert_eq!(snapshot.screen[0].trim_end(), "world");
        assert_eq!(snapshot.screen[1].trim_end(), "next");
    }

    #[test]
    fn handles_alternate_screen_without_polluting_scrollback() {
        let mut display = DisplayState::new(8, 3, DEFAULT_DISPLAY_HISTORY_LIMIT);
        display.process(b"prompt");
        let snapshot = display.process(b"\x1b[?1049hopencode");

        assert!(snapshot.alternate_screen);
        assert!(snapshot.history.is_empty());
        assert_eq!(snapshot.screen[0].trim_end(), "opencode");

        let snapshot = display.process(b"\x1b[?1049l");
        assert!(!snapshot.alternate_screen);
        assert_eq!(snapshot.screen[0].trim_end(), "prompt");
    }

    #[test]
    fn handles_cursor_addressing_and_line_clear() {
        let mut display = DisplayState::new(10, 3, DEFAULT_DISPLAY_HISTORY_LIMIT);
        let snapshot = display.process(b"abc\x1b[2;4Hxyz\x1b[2K\rdone");

        assert_eq!(snapshot.screen[0].trim_end(), "abc");
        assert_eq!(snapshot.screen[1].trim_end(), "done");
    }

    #[test]
    fn handles_tui_erase_chars_and_charset_selection() {
        let mut display = DisplayState::new(10, 2, DEFAULT_DISPLAY_HISTORY_LIMIT);
        let snapshot = display.process(b"abcdef\x1b[1;3H\x1b[3Xxy\x1b(B");

        assert_eq!(snapshot.screen[0].trim_end(), "abxy f");
    }

    #[test]
    fn ignores_tui_string_controls() {
        let mut display = DisplayState::new(20, 2, DEFAULT_DISPLAY_HISTORY_LIMIT);
        let snapshot = display.process(b"abc\x1bP1$r q\x1b\\def\x1b_ignored\x1b\\");

        assert_eq!(snapshot.screen[0].trim_end(), "abcdef");
    }

    #[test]
    fn honors_autowrap_mode() {
        let mut display = DisplayState::new(4, 2, DEFAULT_DISPLAY_HISTORY_LIMIT);
        let snapshot = display.process(b"\x1b[?7labcde");

        assert_eq!(snapshot.screen[0].trim_end(), "abce");
        assert_eq!(snapshot.screen[1].trim_end(), "");
    }

    #[test]
    fn tracks_cursor_visibility_and_clamps_line_end_cursor() {
        let mut display = DisplayState::new(4, 2, DEFAULT_DISPLAY_HISTORY_LIMIT);
        let snapshot = display.process(b"abcd\x1b[?25l");

        assert_eq!(snapshot.cursor_col, 3);
        assert!(!snapshot.cursor_visible);

        let snapshot = display.process(b"\x1b[?25h");
        assert!(snapshot.cursor_visible);
    }

    #[test]
    fn captures_sgr_colors_in_rows() {
        let mut display = DisplayState::new(8, 2, DEFAULT_DISPLAY_HISTORY_LIMIT);
        let snapshot = display.process(b"\x1b[31;44mR\x1b[0mN");

        assert_eq!(snapshot.screen[0].trim_end(), "RN");
        assert_eq!(snapshot.screen_rows[0].spans.len(), 1);
        assert_eq!(snapshot.screen_rows[0].spans[0].start, 0);
        assert_eq!(snapshot.screen_rows[0].spans[0].len, 1);
        assert_eq!(snapshot.screen_rows[0].spans[0].fg, Some([239, 68, 68]));
        assert_eq!(snapshot.screen_rows[0].spans[0].bg, Some([96, 165, 250]));
    }
}
