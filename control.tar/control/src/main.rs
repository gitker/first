use actix_web::{middleware, web, App, HttpRequest, HttpResponse, HttpServer};
use actix_ws::Message;
use aes_gcm::aead::{Aead, KeyInit};
use aes_gcm::{Aes256Gcm, Nonce};
use base64::{engine::general_purpose::STANDARD, Engine as _};
use futures_util::StreamExt;
use hkdf::Hkdf;
use portable_pty::{native_pty_system, Child, CommandBuilder, MasterPty, PtySize};
use rand::{rngs::OsRng, RngCore};
use serde::de::DeserializeOwned;
use serde::{Deserialize, Serialize};
use sha2::Sha256;
use std::collections::{HashMap, VecDeque};
use std::fs;
use std::io::{Read, Write};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::mpsc as std_mpsc;
use std::sync::{Arc, Mutex, Weak};
use std::time::{Duration, Instant};
use tokio::sync::{broadcast, mpsc};
use url::Url;
use uuid::Uuid;

mod display;
mod reverse_proxy;
mod terminal;

const SESSION_SALT_LEN: usize = 16;
const AES_NONCE_LEN: usize = 12;
const KEY_INFO: &[u8] = b"remote-control-v1";
const DEFAULT_ACCESS_TOKEN: &str = "GGRw9oQCGZxePZfRvBln9wzdnwywgqE8";
const MAX_OUTPUT_HISTORY_BYTES: usize = 4 * 1024 * 1024;
const RESUME_TTL: Duration = Duration::MAX;
const SESSION_REAPER_INTERVAL: Duration = Duration::from_secs(60);
const INDEX_FILE_RELATIVE_PATH: &str = "static/index.html";
const CONFIG_FILE_RELATIVE_PATH: &str = "config.json";
const DISPLAY_FRAME_INTERVAL: Duration = Duration::from_millis(16);
const DEFAULT_BIND_ADDR: &str = "0.0.0.0:8080";
const HTTP_PORT: u16 = 8080;

struct AppState {
    access_token: Arc<String>,
    sessions: Arc<Mutex<HashMap<String, Arc<TerminalSession>>>>,
}

struct AccessTokenConfig {
    value: String,
    generated: bool,
}

#[derive(Debug, Default, Deserialize)]
struct AppConfigFile {
    #[serde(default)]
    server: ServerConfigFile,
    #[serde(default)]
    reverse_proxy: reverse_proxy::ReverseProxyFileConfig,
}

#[derive(Debug, Default, Deserialize)]
struct ServerConfigFile {
    bind_addr: Option<String>,
    access_token: Option<String>,
}

#[derive(Clone)]
struct BufferedOutput {
    seq: u64,
    encoded_len: usize,
}

#[derive(Clone)]
enum SessionEvent {
    Display(BufferedDisplay),
    TerminalMode(TerminalModes),
    Closed,
}

#[derive(Clone)]
struct BufferedDisplay {
    output_seq: Option<u64>,
    snapshot: terminal::DisplaySnapshot,
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
struct TerminalModes {
    alternate_screen: bool,
    mouse_tracking: bool,
    mouse_sgr: bool,
    alternate_scroll: bool,
}

#[derive(Default)]
struct TerminalModeTracker {
    state: AnsiParserState,
    csi: Vec<u8>,
    alternate_screen: bool,
    mouse_x10: bool,
    mouse_normal: bool,
    mouse_button: bool,
    mouse_any: bool,
    mouse_sgr: bool,
    alternate_scroll: bool,
}

#[derive(Default)]
enum AnsiParserState {
    #[default]
    Ground,
    Escape,
    Csi,
}

struct OutputHistory {
    entries: VecDeque<BufferedOutput>,
    next_seq: u64,
    total_encoded_len: usize,
}

struct TerminalSession {
    id: String,
    resume_token: String,
    cwd: String,
    master: Arc<Mutex<Box<dyn MasterPty + Send>>>,
    child: Arc<Mutex<Box<dyn Child + Send + Sync>>>,
    input_tx: mpsc::Sender<String>,
    display_tx: std_mpsc::Sender<Option<u64>>,
    history: Mutex<OutputHistory>,
    display: Mutex<display::DisplayState>,
    modes: Mutex<TerminalModes>,
    history_limit: usize,
    events: broadcast::Sender<SessionEvent>,
    current_attachment_id: AtomicU64,
    last_detached_at: Mutex<Option<Instant>>,
    closed: AtomicBool,
}

impl TerminalModeTracker {
    fn process(&mut self, bytes: &[u8]) -> Vec<TerminalModes> {
        let mut changes = Vec::new();

        for &byte in bytes {
            match self.state {
                AnsiParserState::Ground => {
                    if byte == 0x1b {
                        self.state = AnsiParserState::Escape;
                    }
                }
                AnsiParserState::Escape => match byte {
                    b'[' => {
                        self.csi.clear();
                        self.state = AnsiParserState::Csi;
                    }
                    0x1b => {
                        self.state = AnsiParserState::Escape;
                    }
                    _ => {
                        self.state = AnsiParserState::Ground;
                    }
                },
                AnsiParserState::Csi => {
                    if (0x40..=0x7e).contains(&byte) {
                        if let Some(modes) = self.handle_csi(byte) {
                            changes.push(modes);
                        }
                        self.state = AnsiParserState::Ground;
                    } else if self.csi.len() < 128 {
                        self.csi.push(byte);
                    } else {
                        self.state = AnsiParserState::Ground;
                    }
                }
            }
        }

        changes
    }

    fn handle_csi(&mut self, final_byte: u8) -> Option<TerminalModes> {
        if final_byte != b'h' && final_byte != b'l' {
            return None;
        }

        let params = self.csi.strip_prefix(b"?")?;
        let params = std::str::from_utf8(params).ok()?;
        let enabled = final_byte == b'h';
        let before = self.current_modes();

        for param in params.split(';') {
            let Ok(mode) = param.parse::<u16>() else {
                continue;
            };

            match mode {
                47 | 1047 | 1049 => self.alternate_screen = enabled,
                9 => self.mouse_x10 = enabled,
                1000 => self.mouse_normal = enabled,
                1002 => self.mouse_button = enabled,
                1003 => self.mouse_any = enabled,
                1006 => self.mouse_sgr = enabled,
                1007 => self.alternate_scroll = enabled,
                _ => {}
            }
        }

        let after = self.current_modes();
        (after != before).then_some(after)
    }

    fn current_modes(&self) -> TerminalModes {
        TerminalModes {
            alternate_screen: self.alternate_screen,
            mouse_tracking: self.mouse_x10
                || self.mouse_normal
                || self.mouse_button
                || self.mouse_any,
            mouse_sgr: self.mouse_sgr,
            alternate_scroll: self.alternate_scroll,
        }
    }
}

impl TerminalSession {
    fn new(
        id: String,
        resume_token: String,
        cwd: String,
        master: Arc<Mutex<Box<dyn MasterPty + Send>>>,
        child: Arc<Mutex<Box<dyn Child + Send + Sync>>>,
        input_tx: mpsc::Sender<String>,
        display_tx: std_mpsc::Sender<Option<u64>>,
        cols: u16,
        rows: u16,
        history_limit: usize,
    ) -> Self {
        let (events, _) = broadcast::channel(256);

        Self {
            id,
            resume_token,
            cwd,
            master,
            child,
            input_tx,
            display_tx,
            history: Mutex::new(OutputHistory {
                entries: VecDeque::new(),
                next_seq: 1,
                total_encoded_len: 0,
            }),
            display: Mutex::new(display::DisplayState::new(cols, rows, history_limit)),
            modes: Mutex::new(TerminalModes::default()),
            history_limit,
            events,
            current_attachment_id: AtomicU64::new(0),
            last_detached_at: Mutex::new(None),
            closed: AtomicBool::new(false),
        }
    }

    fn is_resumable(&self, resume_token: &str) -> bool {
        !self.closed.load(Ordering::SeqCst) && self.resume_token == resume_token
    }

    fn begin_attachment(&self) -> u64 {
        let attachment_id = self.current_attachment_id.fetch_add(1, Ordering::SeqCst) + 1;
        if let Ok(mut last_detached_at) = self.last_detached_at.lock() {
            *last_detached_at = None;
        }
        attachment_id
    }

    fn is_current_attachment(&self, attachment_id: u64) -> bool {
        self.current_attachment_id.load(Ordering::SeqCst) == attachment_id
            && !self.closed.load(Ordering::SeqCst)
    }

    fn mark_detached(&self, attachment_id: u64) {
        if self.current_attachment_id.load(Ordering::SeqCst) != attachment_id {
            return;
        }

        self.current_attachment_id.store(0, Ordering::SeqCst);
        if let Ok(mut last_detached_at) = self.last_detached_at.lock() {
            *last_detached_at = Some(Instant::now());
        }
    }

    fn subscribe(&self) -> broadcast::Receiver<SessionEvent> {
        self.events.subscribe()
    }

    fn push_output(&self, bytes: Vec<u8>) {
        if self.closed.load(Ordering::SeqCst) {
            return;
        }

        {
            let mut display = self.display.lock().expect("display mutex poisoned");
            display.process(&bytes);
        }

        let output = {
            let mut history = self.history.lock().expect("output history mutex poisoned");
            let output = BufferedOutput {
                seq: history.next_seq,
                encoded_len: bytes.len(),
            };
            history.next_seq += 1;
            history.total_encoded_len += output.encoded_len;
            history.entries.push_back(output.clone());

            while history.total_encoded_len > MAX_OUTPUT_HISTORY_BYTES {
                if let Some(evicted) = history.entries.pop_front() {
                    history.total_encoded_len = history
                        .total_encoded_len
                        .saturating_sub(evicted.encoded_len);
                } else {
                    break;
                }
            }

            output
        };

        let output_seq = output.seq;
        let _ = self.display_tx.send(Some(output_seq));
    }

    fn update_modes(&self, modes: TerminalModes) {
        if self.closed.load(Ordering::SeqCst) {
            return;
        }

        let changed = {
            let mut current = self.modes.lock().expect("terminal modes mutex poisoned");
            if *current == modes {
                false
            } else {
                *current = modes;
                true
            }
        };

        if changed {
            let _ = self.events.send(SessionEvent::TerminalMode(modes));
        }
    }

    fn current_modes(&self) -> TerminalModes {
        *self.modes.lock().expect("terminal modes mutex poisoned")
    }

    fn backlog_since(&self, last_output_seq: u64) -> Vec<BufferedOutput> {
        let history = self.history.lock().expect("output history mutex poisoned");
        history
            .entries
            .iter()
            .filter(|entry| entry.seq > last_output_seq)
            .cloned()
            .collect()
    }

    fn resize(&self, cols: u16, rows: u16) {
        if let Ok(master) = self.master.lock() {
            let _ = master.resize(pty_size(cols, rows));
        }

        let snapshot = {
            let mut display = self.display.lock().expect("display mutex poisoned");
            display.resize(cols, rows)
        };
        let _ = self.events.send(SessionEvent::Display(BufferedDisplay {
            output_seq: None,
            snapshot,
        }));
    }

    async fn send_input(&self, data: String) -> Result<(), mpsc::error::SendError<String>> {
        self.input_tx.send(data).await
    }

    fn ready_payload(&self, resumed: bool) -> terminal::ServerPayload {
        let modes = self.current_modes();
        let display = self
            .display
            .lock()
            .expect("display mutex poisoned")
            .snapshot();
        terminal::ServerPayload::ready(
            self.cwd.clone(),
            self.id.clone(),
            self.resume_token.clone(),
            resumed,
            modes.alternate_screen,
            modes.mouse_tracking,
            modes.mouse_sgr,
            modes.alternate_scroll,
            display,
        )
    }

    fn terminal_mode_payload(modes: TerminalModes) -> terminal::ServerPayload {
        terminal::ServerPayload::terminal_mode(
            modes.alternate_screen,
            modes.mouse_tracking,
            modes.mouse_sgr,
            modes.alternate_scroll,
        )
    }

    fn display_delta_payload(
        display_delta: terminal::DisplayDelta,
        output_seq: Option<u64>,
    ) -> terminal::ServerPayload {
        terminal::ServerPayload::display_delta(display_delta, output_seq)
    }

    fn current_display_snapshot(&self) -> terminal::DisplaySnapshot {
        self.display
            .lock()
            .expect("display mutex poisoned")
            .snapshot()
    }

    fn request_shutdown(&self) {
        if self.closed.swap(true, Ordering::SeqCst) {
            return;
        }

        let _ = self.events.send(SessionEvent::Closed);
        if let Ok(mut child) = self.child.lock() {
            let _ = child.kill();
        }
    }

    fn mark_closed(&self) {
        if self.closed.swap(true, Ordering::SeqCst) {
            return;
        }

        let _ = self.events.send(SessionEvent::Closed);
    }

    fn is_stale(&self, now: Instant) -> bool {
        if self.closed.load(Ordering::SeqCst) {
            return true;
        }

        if self.current_attachment_id.load(Ordering::SeqCst) != 0 {
            return false;
        }

        match self.last_detached_at.lock() {
            Ok(last_detached_at) => last_detached_at
                .map(|detached_at| now.duration_since(detached_at) >= RESUME_TTL)
                .unwrap_or(false),
            Err(_) => true,
        }
    }
}

#[cfg(windows)]
const POWERSHELL_BOOTSTRAP: &str = r#"
$utf8NoBom = [System.Text.UTF8Encoding]::new($false)
[Console]::InputEncoding = $utf8NoBom
[Console]::OutputEncoding = $utf8NoBom
$OutputEncoding = $utf8NoBom
try { [Console]::TreatControlCAsInput = $true } catch {}

function global:Resolve-RemoteControlPath {
    param([string]$Path)

    if ([string]::IsNullOrWhiteSpace($Path)) {
        return $Path
    }

    $uri = $null
    if (-not [System.Uri]::TryCreate($Path, [System.UriKind]::Absolute, [ref]$uri)) {
        return $Path
    }

    if (-not $uri.IsFile) {
        return $Path
    }

    return $uri.LocalPath
}

function global:Set-RemoteLocation {
    [CmdletBinding(DefaultParameterSetName='Path')]
    param(
        [Parameter(ParameterSetName='Path', Position=0, ValueFromPipeline=$true, ValueFromPipelineByPropertyName=$true)]
        [string]$Path,
        [Parameter(ParameterSetName='LiteralPath', ValueFromPipelineByPropertyName=$true)]
        [Alias('PSPath', 'LP')]
        [string]$LiteralPath,
        [string]$StackName,
        [switch]$PassThru
    )

    $callArgs = @{}

    if ($PSBoundParameters.ContainsKey('StackName')) {
        $callArgs['StackName'] = $StackName
    }

    if ($PSBoundParameters.ContainsKey('PassThru')) {
        $callArgs['PassThru'] = $true
    }

    if ($PSBoundParameters.ContainsKey('LiteralPath')) {
        $callArgs['LiteralPath'] = Resolve-RemoteControlPath $LiteralPath
    } elseif ($PSBoundParameters.ContainsKey('Path')) {
        $callArgs['Path'] = Resolve-RemoteControlPath $Path
    }

    Microsoft.PowerShell.Management\Set-Location @callArgs
}

Set-Alias -Name cd -Value Set-RemoteLocation -Option AllScope -Scope Global
Set-Alias -Name chdir -Value Set-RemoteLocation -Option AllScope -Scope Global
"#;

#[derive(Debug, PartialEq, Eq)]
struct TerminalShell {
    program: String,
    args: Vec<String>,
}

impl TerminalShell {
    fn command(&self) -> CommandBuilder {
        let mut command = CommandBuilder::new(&self.program);
        for arg in &self.args {
            command.arg(arg);
        }
        command
    }

    fn display_name(&self) -> &str {
        self.program
            .rsplit(['/', '\\'])
            .next()
            .filter(|name| !name.is_empty())
            .unwrap_or(&self.program)
    }
}

#[cfg(windows)]
fn terminal_shell() -> TerminalShell {
    TerminalShell {
        program: "powershell.exe".to_owned(),
        args: vec![
            "-NoLogo".to_owned(),
            "-NoProfile".to_owned(),
            "-NoExit".to_owned(),
            "-Command".to_owned(),
            POWERSHELL_BOOTSTRAP.to_owned(),
        ],
    }
}

#[cfg(unix)]
fn terminal_shell() -> TerminalShell {
    let program = std::env::var("SHELL")
        .ok()
        .map(|shell| shell.trim().to_owned())
        .filter(|shell| !shell.is_empty())
        .unwrap_or_else(default_unix_shell);

    TerminalShell {
        program,
        args: Vec::new(),
    }
}

#[cfg(all(not(windows), not(unix)))]
fn terminal_shell() -> TerminalShell {
    TerminalShell {
        program: "sh".to_owned(),
        args: Vec::new(),
    }
}

#[cfg(unix)]
fn default_unix_shell() -> String {
    if cfg!(target_os = "macos") {
        "/bin/zsh".to_owned()
    } else if Path::new("/bin/bash").exists() {
        "/bin/bash".to_owned()
    } else {
        "/bin/sh".to_owned()
    }
}

fn normalize_path(path: &str) -> String {
    let trimmed = path.trim();

    match Url::parse(trimmed) {
        Ok(url) if url.scheme() == "file" => url
            .to_file_path()
            .ok()
            .and_then(|file_path| file_path.into_os_string().into_string().ok())
            .unwrap_or_else(|| trimmed.to_owned()),
        _ => trimmed.to_owned(),
    }
}

fn resolve_initial_cwd(requested_cwd: Option<&str>) -> String {
    requested_cwd
        .map(normalize_path)
        .filter(|path| !path.is_empty() && Path::new(path).is_dir())
        .unwrap_or_else(default_cwd)
}

fn default_cwd() -> String {
    platform_preferred_cwd()
        .or_else(|| std::env::current_dir().ok().filter(|path| path.is_dir()))
        .and_then(path_to_string)
        .unwrap_or_else(platform_root_cwd)
}

#[cfg(windows)]
fn platform_preferred_cwd() -> Option<PathBuf> {
    let root = PathBuf::from(r"C:\");
    if root.is_dir() {
        Some(root)
    } else {
        home_dir().filter(|path| path.is_dir())
    }
}

#[cfg(unix)]
fn platform_preferred_cwd() -> Option<PathBuf> {
    home_dir().filter(|path| path.is_dir())
}

#[cfg(all(not(windows), not(unix)))]
fn platform_preferred_cwd() -> Option<PathBuf> {
    home_dir().filter(|path| path.is_dir())
}

fn home_dir() -> Option<PathBuf> {
    #[cfg(windows)]
    {
        std::env::var_os("USERPROFILE")
            .map(PathBuf::from)
            .or_else(|| {
                let drive = std::env::var_os("HOMEDRIVE")?;
                let path = std::env::var_os("HOMEPATH")?;
                let mut home = PathBuf::from(drive);
                home.push(path);
                Some(home)
            })
    }

    #[cfg(unix)]
    {
        std::env::var_os("HOME").map(PathBuf::from)
    }

    #[cfg(all(not(windows), not(unix)))]
    {
        None
    }
}

fn path_to_string(path: PathBuf) -> Option<String> {
    path.into_os_string().into_string().ok()
}

#[cfg(windows)]
fn platform_root_cwd() -> String {
    r"C:\".to_owned()
}

#[cfg(unix)]
fn platform_root_cwd() -> String {
    "/".to_owned()
}

#[cfg(all(not(windows), not(unix)))]
fn platform_root_cwd() -> String {
    ".".to_owned()
}

fn config_file_path() -> PathBuf {
    if let Some(path) = std::env::var_os("REMOTE_CONTROL_CONFIG").map(PathBuf::from) {
        return path;
    }

    let cwd_config = std::env::current_dir()
        .ok()
        .map(|cwd| cwd.join(CONFIG_FILE_RELATIVE_PATH));
    if let Some(path) = cwd_config.filter(|path| path.is_file()) {
        return path;
    }

    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join(CONFIG_FILE_RELATIVE_PATH)
}

fn load_app_config() -> AppConfigFile {
    let path = config_file_path();
    match fs::read_to_string(&path) {
        Ok(config) => match serde_json::from_str::<AppConfigFile>(&config) {
            Ok(config) => {
                log::info!("Loaded configuration from {}", path.display());
                config
            }
            Err(error) => {
                log::warn!(
                    "Failed to parse configuration from {}: {}; using defaults",
                    path.display(),
                    error
                );
                AppConfigFile::default()
            }
        },
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
            log::warn!(
                "Configuration file {} not found; using defaults",
                path.display()
            );
            AppConfigFile::default()
        }
        Err(error) => {
            log::warn!(
                "Failed to read configuration from {}: {}; using defaults",
                path.display(),
                error
            );
            AppConfigFile::default()
        }
    }
}

fn configured_bind_addr(server_config: &ServerConfigFile) -> String {
    std::env::var("REMOTE_CONTROL_BIND_ADDR")
        .ok()
        .map(|addr| addr.trim().to_owned())
        .filter(|addr| !addr.is_empty())
        .or_else(|| {
            server_config
                .bind_addr
                .as_deref()
                .map(str::trim)
                .filter(|addr| !addr.is_empty())
                .map(str::to_owned)
        })
        .unwrap_or_else(|| DEFAULT_BIND_ADDR.to_owned())
}

fn configured_bind_port(bind_addr: &str) -> u16 {
    bind_addr
        .rsplit_once(':')
        .and_then(|(_, port)| port.parse::<u16>().ok())
        .unwrap_or(HTTP_PORT)
}

fn load_access_token(config_token: Option<&str>) -> AccessTokenConfig {
    match std::env::var("REMOTE_CONTROL_ACCESS_TOKEN") {
        Ok(token) if !token.trim().is_empty() => AccessTokenConfig {
            value: token.trim().to_owned(),
            generated: false,
        },
        _ => match config_token
            .map(str::trim)
            .filter(|token| !token.is_empty())
        {
            Some(token) => AccessTokenConfig {
                value: token.to_owned(),
                generated: false,
            },
            None => AccessTokenConfig {
                value: DEFAULT_ACCESS_TOKEN.to_owned(),
                generated: true,
            },
        },
    }
}

fn config_access_token(config: &AppConfigFile) -> Option<&str> {
    config.server.access_token.as_deref()
}

fn random_bytes<const N: usize>() -> [u8; N] {
    let mut bytes = [0u8; N];
    OsRng.fill_bytes(&mut bytes);
    bytes
}

fn random_token() -> String {
    Uuid::new_v4().simple().to_string()
}

fn derive_cipher(access_token: &str, salt: &[u8]) -> Result<Aes256Gcm, String> {
    let hkdf = Hkdf::<Sha256>::new(Some(salt), access_token.as_bytes());
    let mut key = [0u8; 32];
    hkdf.expand(KEY_INFO, &mut key)
        .map_err(|_| "Failed to derive session key".to_string())?;

    Aes256Gcm::new_from_slice(&key).map_err(|_| "Failed to create AES-GCM cipher".to_string())
}

fn encrypt_payload<T: Serialize>(cipher: &Aes256Gcm, payload: &T) -> Result<String, String> {
    let plaintext = serde_json::to_vec(payload)
        .map_err(|error| format!("Failed to serialize payload: {}", error))?;
    let nonce_bytes = random_bytes::<AES_NONCE_LEN>();
    let nonce = Nonce::from_slice(&nonce_bytes);
    let ciphertext = cipher
        .encrypt(nonce, plaintext.as_ref())
        .map_err(|_| "Failed to encrypt payload".to_string())?;

    serde_json::to_string(&terminal::EncryptedEnvelope {
        nonce: STANDARD.encode(nonce_bytes),
        ciphertext: STANDARD.encode(ciphertext),
    })
    .map_err(|error| format!("Failed to encode envelope: {}", error))
}

fn decrypt_payload<T: DeserializeOwned>(cipher: &Aes256Gcm, payload: &str) -> Result<T, String> {
    let envelope: terminal::EncryptedEnvelope = serde_json::from_str(payload)
        .map_err(|error| format!("Invalid encrypted envelope: {}", error))?;
    let nonce_bytes = STANDARD
        .decode(envelope.nonce)
        .map_err(|error| format!("Invalid nonce encoding: {}", error))?;
    let ciphertext = STANDARD
        .decode(envelope.ciphertext)
        .map_err(|error| format!("Invalid ciphertext encoding: {}", error))?;

    if nonce_bytes.len() != AES_NONCE_LEN {
        return Err("Invalid nonce length".to_string());
    }

    let nonce = Nonce::from_slice(&nonce_bytes);
    let plaintext = cipher
        .decrypt(nonce, ciphertext.as_ref())
        .map_err(|_| "Failed to decrypt payload".to_string())?;

    serde_json::from_slice(&plaintext)
        .map_err(|error| format!("Failed to decode decrypted payload: {}", error))
}

async fn send_plain_json<T: Serialize>(
    session: &mut actix_ws::Session,
    payload: &T,
) -> Result<(), actix_web::Error> {
    let text =
        serde_json::to_string(payload).map_err(actix_web::error::ErrorInternalServerError)?;
    session
        .text(text)
        .await
        .map_err(actix_web::error::ErrorInternalServerError)
}

async fn send_encrypted_json<T: Serialize>(
    session: &mut actix_ws::Session,
    cipher: &Aes256Gcm,
    payload: &T,
) -> Result<(), actix_web::Error> {
    let text =
        encrypt_payload(cipher, payload).map_err(actix_web::error::ErrorInternalServerError)?;
    session
        .text(text)
        .await
        .map_err(actix_web::error::ErrorInternalServerError)
}

fn pty_size(cols: u16, rows: u16) -> PtySize {
    PtySize {
        rows: rows.max(1),
        cols: cols.max(1),
        pixel_width: 0,
        pixel_height: 0,
    }
}

fn pump_pty_output<R>(mut reader: R, terminal_session: Arc<TerminalSession>)
where
    R: Read,
{
    let mut buf = [0u8; 4096];
    let mut mode_tracker = TerminalModeTracker::default();

    loop {
        match reader.read(&mut buf) {
            Ok(0) => break,
            Ok(n) => {
                let bytes = &buf[..n];
                let mode_changes = mode_tracker.process(bytes);
                terminal_session.push_output(bytes.to_vec());
                for modes in mode_changes {
                    terminal_session.update_modes(modes);
                }
            }
            Err(_) => break,
        }
    }
}

fn insert_session(app_state: &AppState, terminal_session: Arc<TerminalSession>) {
    let mut sessions = app_state
        .sessions
        .lock()
        .expect("session map mutex poisoned");
    sessions.insert(terminal_session.id.clone(), terminal_session);
}

fn find_resumable_session(
    app_state: &AppState,
    session_id: &str,
    resume_token: &str,
) -> Option<Arc<TerminalSession>> {
    let sessions = app_state
        .sessions
        .lock()
        .expect("session map mutex poisoned");
    sessions
        .get(session_id)
        .filter(|session| session.is_resumable(resume_token))
        .cloned()
}

fn remove_session(app_state: &AppState, session_id: &str) -> Option<Arc<TerminalSession>> {
    let mut sessions = app_state
        .sessions
        .lock()
        .expect("session map mutex poisoned");
    sessions.remove(session_id)
}

fn spawn_session_exit_watcher(
    app_state: Arc<AppState>,
    session_id: String,
    child: Arc<Mutex<Box<dyn Child + Send + Sync>>>,
    session: Weak<TerminalSession>,
) {
    std::thread::spawn(move || {
        if let Ok(mut child) = child.lock() {
            let _ = child.wait();
        }

        if let Some(session) = session.upgrade() {
            session.mark_closed();
        }

        let _ = remove_session(app_state.as_ref(), &session_id);
    });
}

fn spawn_display_pump(
    terminal_session: Arc<TerminalSession>,
    display_rx: std_mpsc::Receiver<Option<u64>>,
) {
    std::thread::spawn(move || {
        let mut pending_seq = None;

        loop {
            match display_rx.recv() {
                Ok(next_seq) => merge_output_seq(&mut pending_seq, next_seq),
                Err(_) => break,
            }

            let deadline = Instant::now() + DISPLAY_FRAME_INTERVAL;
            loop {
                let now = Instant::now();
                if now >= deadline {
                    break;
                }

                match display_rx.recv_timeout(deadline.saturating_duration_since(now)) {
                    Ok(next_seq) => merge_output_seq(&mut pending_seq, next_seq),
                    Err(std_mpsc::RecvTimeoutError::Timeout) => break,
                    Err(std_mpsc::RecvTimeoutError::Disconnected) => return,
                }
            }

            if terminal_session.closed.load(Ordering::SeqCst) {
                break;
            }

            let snapshot = terminal_session
                .display
                .lock()
                .expect("display mutex poisoned")
                .snapshot();
            let _ = terminal_session
                .events
                .send(SessionEvent::Display(BufferedDisplay {
                    output_seq: pending_seq.take(),
                    snapshot,
                }));
        }
    });
}

fn merge_output_seq(current: &mut Option<u64>, next: Option<u64>) {
    if let Some(next) = next {
        *current = Some(current.map_or(next, |current| current.max(next)));
    }
}

fn build_display_delta(
    previous: Option<&terminal::DisplaySnapshot>,
    next: &terminal::DisplaySnapshot,
) -> terminal::DisplayDelta {
    let history = match previous {
        Some(previous) if previous.history == next.history => None,
        _ => Some(next.history.clone()),
    };

    let mut screen_rows = Vec::new();
    let force_rows = previous
        .map(|previous| {
            previous.cols != next.cols
                || previous.rows != next.rows
                || previous.alternate_screen != next.alternate_screen
        })
        .unwrap_or(true);

    for (row, data) in next.screen_rows.iter().enumerate() {
        let changed = previous
            .and_then(|previous| previous.screen_rows.get(row))
            .map(|previous_row| previous_row != data)
            .unwrap_or(true);

        if force_rows || changed {
            screen_rows.push(terminal::DisplayRowPatch {
                row: row as u16,
                data: data.clone(),
            });
        }
    }

    terminal::DisplayDelta {
        cols: next.cols,
        rows: next.rows,
        full: force_rows,
        history,
        screen_rows,
        cursor_col: next.cursor_col,
        cursor_row: next.cursor_row,
        cursor_visible: next.cursor_visible,
        alternate_screen: next.alternate_screen,
    }
}

fn create_terminal_session(
    app_state: Arc<AppState>,
    cwd: String,
    cols: u16,
    rows: u16,
    history_limit: usize,
) -> Result<Arc<TerminalSession>, String> {
    let pty_system = native_pty_system();
    let pty_pair = pty_system
        .openpty(pty_size(cols, rows))
        .map_err(|error| format!("Failed to create terminal PTY: {}", error))?;

    let reader = pty_pair
        .master
        .try_clone_reader()
        .map_err(|error| format!("Failed to attach terminal output: {}", error))?;
    let writer = pty_pair
        .master
        .take_writer()
        .map_err(|error| format!("Failed to attach terminal input: {}", error))?;

    let master = Arc::new(Mutex::new(pty_pair.master));

    let shell = terminal_shell();
    let mut command = shell.command();
    command.cwd(cwd.clone());
    command.env("TERM", "xterm-256color");
    command.env("COLORTERM", "truecolor");

    let child = pty_pair
        .slave
        .spawn_command(command)
        .map_err(|error| format!("Failed to spawn {}: {}", shell.display_name(), error))?;

    drop(pty_pair.slave);

    let child = Arc::new(Mutex::new(child));
    let (input_tx, mut input_rx) = mpsc::channel::<String>(256);
    let (display_tx, display_rx) = std_mpsc::channel::<Option<u64>>();
    let terminal_session = Arc::new(TerminalSession::new(
        random_token(),
        random_token(),
        cwd,
        Arc::clone(&master),
        Arc::clone(&child),
        input_tx,
        display_tx,
        cols,
        rows,
        history_limit,
    ));

    let output_session = Arc::clone(&terminal_session);
    std::thread::spawn(move || {
        pump_pty_output(reader, output_session);
    });

    std::thread::spawn(move || {
        let mut writer = writer;
        while let Some(data) = input_rx.blocking_recv() {
            if writer.write_all(data.as_bytes()).is_err() {
                break;
            }

            if writer.flush().is_err() {
                break;
            }
        }
    });

    spawn_session_exit_watcher(
        Arc::clone(&app_state),
        terminal_session.id.clone(),
        Arc::clone(&child),
        Arc::downgrade(&terminal_session),
    );
    spawn_display_pump(Arc::clone(&terminal_session), display_rx);

    insert_session(app_state.as_ref(), Arc::clone(&terminal_session));
    Ok(terminal_session)
}

fn index_file_path() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join(INDEX_FILE_RELATIVE_PATH)
}

async fn index() -> HttpResponse {
    match tokio::fs::read_to_string(index_file_path()).await {
        Ok(contents) => HttpResponse::Ok()
            .content_type("text/html; charset=utf-8")
            .body(contents),
        Err(error) => {
            log::error!("Failed to read {}: {}", INDEX_FILE_RELATIVE_PATH, error);
            HttpResponse::InternalServerError()
                .content_type("text/plain; charset=utf-8")
                .body("Failed to load index.html")
        }
    }
}

async fn run_session_reaper(app_state: web::Data<AppState>) {
    loop {
        tokio::time::sleep(SESSION_REAPER_INTERVAL).await;

        let stale_session_ids = {
            let sessions = app_state
                .sessions
                .lock()
                .expect("session map mutex poisoned");
            let now = Instant::now();
            sessions
                .iter()
                .filter_map(|(session_id, session)| {
                    if session.is_stale(now) {
                        Some(session_id.clone())
                    } else {
                        None
                    }
                })
                .collect::<Vec<_>>()
        };

        for session_id in stale_session_ids {
            if let Some(session) = remove_session(app_state.as_ref(), &session_id) {
                log::info!("Reaping detached terminal session: {}", session_id);
                session.request_shutdown();
            }
        }
    }
}

async fn ws_handler(
    req: HttpRequest,
    body: web::Payload,
    app_state: web::Data<AppState>,
) -> Result<HttpResponse, actix_web::Error> {
    let (response, mut socket, mut msg_stream) = actix_ws::handle(&req, body)?;
    let app_state = app_state.clone();

    actix_web::rt::spawn(async move {
        let session_salt = random_bytes::<SESSION_SALT_LEN>();
        let session_cipher = match derive_cipher(app_state.access_token.as_ref(), &session_salt) {
            Ok(cipher) => Arc::new(cipher),
            Err(error) => {
                log::error!("Failed to derive session cipher: {}", error);
                let _ = socket.close(None).await;
                return;
            }
        };

        if send_plain_json(
            &mut socket,
            &terminal::ServerHello {
                r#type: "hello",
                salt: STANDARD.encode(session_salt),
            },
        )
        .await
        .is_err()
        {
            return;
        }

        let auth_message = match msg_stream.next().await {
            Some(Ok(Message::Text(text))) => text.to_string(),
            Some(Ok(Message::Close(_))) | None => {
                let _ = socket.close(None).await;
                return;
            }
            Some(Ok(_)) => {
                let _ = socket.close(None).await;
                return;
            }
            Some(Err(error)) => {
                log::warn!("Authentication stream error: {}", error);
                let _ = socket.close(None).await;
                return;
            }
        };

        let auth_payload: terminal::ClientPayload = match decrypt_payload::<terminal::ClientPayload>(
            session_cipher.as_ref(),
            &auth_message,
        ) {
            Ok(payload) if payload.r#type == "auth" => payload,
            Ok(_) => {
                let _ = socket.close(None).await;
                return;
            }
            Err(error) => {
                log::warn!("Authentication failed: {}", error);
                let _ = socket.close(None).await;
                return;
            }
        };

        let cwd = resolve_initial_cwd(auth_payload.cwd.as_deref());
        let cols = auth_payload.cols.unwrap_or(120);
        let rows = auth_payload.rows.unwrap_or(30);
        let requested_last_seq = auth_payload.last_output_seq.unwrap_or(0);
        let history_limit = auth_payload
            .history_limit
            .unwrap_or(5000)
            .max(100)
            .min(100000);

        let (mut terminal_session, resumed) = match (
            auth_payload.session_id.as_deref(),
            auth_payload.resume_token.as_deref(),
        ) {
            (Some(session_id), Some(resume_token)) => {
                match find_resumable_session(app_state.as_ref(), session_id, resume_token) {
                    Some(existing_session) => {
                        log::info!("Resumed terminal session: {}", existing_session.id);
                        existing_session.resize(cols, rows);
                        (existing_session, true)
                    }
                    None => {
                        log::info!("Resume target missing, creating a new terminal session.");
                        match create_terminal_session(
                            Arc::new(app_state.get_ref().clone()),
                            cwd.clone(),
                            cols,
                            rows,
                            history_limit,
                        ) {
                            Ok(new_session) => (new_session, false),
                            Err(error) => {
                                let _ = send_encrypted_json(
                                    &mut socket,
                                    session_cipher.as_ref(),
                                    &terminal::ServerPayload::error(error),
                                )
                                .await;
                                let _ = socket.close(None).await;
                                return;
                            }
                        }
                    }
                }
            }
            _ => match create_terminal_session(
                Arc::new(app_state.get_ref().clone()),
                cwd.clone(),
                cols,
                rows,
                history_limit,
            ) {
                Ok(new_session) => {
                    log::info!("Created terminal session: {}", new_session.id);
                    (new_session, false)
                }
                Err(error) => {
                    let _ = send_encrypted_json(
                        &mut socket,
                        session_cipher.as_ref(),
                        &terminal::ServerPayload::error(error),
                    )
                    .await;
                    let _ = socket.close(None).await;
                    return;
                }
            },
        };

        let mut attachment_id = terminal_session.begin_attachment();
        let mut output_rx = terminal_session.subscribe();
        let mut delivered_output_seq = requested_last_seq;

        if send_encrypted_json(
            &mut socket,
            session_cipher.as_ref(),
            &terminal_session.ready_payload(resumed),
        )
        .await
        .is_err()
        {
            terminal_session.mark_detached(attachment_id);
            return;
        }
        let mut last_display_snapshot = Some(terminal_session.current_display_snapshot());

        for output in terminal_session.backlog_since(requested_last_seq) {
            if !terminal_session.is_current_attachment(attachment_id) {
                break;
            }
            delivered_output_seq = output.seq;
        }

        let mut explicit_disconnect = false;

        loop {
            tokio::select! {
                maybe_msg = msg_stream.next() => {
                    let msg = match maybe_msg {
                        Some(Ok(message)) => message,
                        Some(Err(error)) => {
                            log::warn!("WebSocket stream error: {}", error);
                            break;
                        }
                        None => break,
                    };

                    if !terminal_session.is_current_attachment(attachment_id) {
                        if terminal_session.closed.load(Ordering::SeqCst) {
                            continue;
                        }
                        break;
                    }

                    match msg {
                        Message::Text(text) => {
                            let text_str = text.to_string();
                            match decrypt_payload::<terminal::ClientPayload>(session_cipher.as_ref(), &text_str) {
                                Ok(cmd) => match cmd.r#type.as_str() {
                                    "input" => {
                                        if let Some(data) = cmd.data {
                                            if terminal_session.send_input(data).await.is_err() {
                                                if !terminal_session.closed.load(Ordering::SeqCst) {
                                                    log::warn!(
                                                        "Input channel closed for session {}; marking closed for restart",
                                                        terminal_session.id
                                                    );
                                                    terminal_session.mark_closed();
                                                }
                                            }
                                        }
                                    }
                                    "resize" => {
                                        if let (Some(next_cols), Some(next_rows)) = (cmd.cols, cmd.rows) {
                                            let session = Arc::clone(&terminal_session);
                                            let _ = tokio::task::spawn_blocking(move || {
                                                session.resize(next_cols, next_rows);
                                            }).await;
                                        }
                                    }
                                    "ping" => {
                                        if send_encrypted_json(
                                            &mut socket,
                                            session_cipher.as_ref(),
                                            &terminal::ServerPayload::pong(),
                                        )
                                        .await
                                        .is_err()
                                        {
                                            break;
                                        }
                                    }
                                    "disconnect" => {
                                        explicit_disconnect = true;
                                        if let Some(session) = remove_session(app_state.as_ref(), &terminal_session.id) {
                                            session.request_shutdown();
                                        } else {
                                            terminal_session.request_shutdown();
                                        }
                                        break;
                                    }
                                    _ => {}
                                },
                                Err(error) => {
                                    log::warn!("Dropping invalid encrypted message: {}", error);
                                    break;
                                }
                            }
                        }
                        Message::Close(_) => break,
                        Message::Ping(bytes) => {
                            if socket.pong(&bytes).await.is_err() {
                                break;
                            }
                        }
                        Message::Pong(_) => {}
                        _ => {}
                    }
                }
                event = output_rx.recv() => {
                    match event {
                        Ok(SessionEvent::Closed) | Err(broadcast::error::RecvError::Closed) => {
                            let old_session_id = terminal_session.id.clone();
                            let snapshot = terminal_session.current_display_snapshot();
                            let next_cwd = terminal_session.cwd.clone();
                            let _ = remove_session(app_state.as_ref(), &old_session_id);

                            log::warn!(
                                "Terminal child exited unexpectedly; restarting session {}",
                                old_session_id
                            );

                            match create_terminal_session(
                                Arc::new(app_state.get_ref().clone()),
                                next_cwd,
                                snapshot.cols,
                                snapshot.rows,
                                terminal_session.history_limit,
                            ) {
                                Ok(new_session) => {
                                    terminal_session = new_session;
                                    attachment_id = terminal_session.begin_attachment();
                                    output_rx = terminal_session.subscribe();
                                    delivered_output_seq = 0;
                                    last_display_snapshot =
                                        Some(terminal_session.current_display_snapshot());

                                    if send_encrypted_json(
                                        &mut socket,
                                        session_cipher.as_ref(),
                                        &terminal_session.ready_payload(false),
                                    )
                                    .await
                                    .is_err()
                                    {
                                        break;
                                    }
                                }
                                Err(error) => {
                                    let _ = send_encrypted_json(
                                        &mut socket,
                                        session_cipher.as_ref(),
                                        &terminal::ServerPayload::error(error),
                                    )
                                    .await;
                                    break;
                                }
                            }
                        }
                        Ok(SessionEvent::TerminalMode(modes)) => {
                            if !terminal_session.is_current_attachment(attachment_id) {
                                break;
                            }
                            if send_encrypted_json(
                                &mut socket,
                                session_cipher.as_ref(),
                                &TerminalSession::terminal_mode_payload(modes),
                            )
                            .await
                            .is_err()
                            {
                                break;
                            }
                        }
                        Ok(SessionEvent::Display(display)) => {
                            if !terminal_session.is_current_attachment(attachment_id) {
                                break;
                            }
                            if let Some(output_seq) = display.output_seq {
                                delivered_output_seq = output_seq;
                            }
                            let delta = build_display_delta(
                                last_display_snapshot.as_ref(),
                                &display.snapshot,
                            );
                            last_display_snapshot = Some(display.snapshot);
                            if send_encrypted_json(
                                &mut socket,
                                session_cipher.as_ref(),
                                &TerminalSession::display_delta_payload(delta, display.output_seq),
                            )
                            .await
                            .is_err()
                            {
                                break;
                            }
                        }
                        Err(broadcast::error::RecvError::Lagged(_)) => {
                            if !terminal_session.is_current_attachment(attachment_id) {
                                break;
                            }
                            for output in terminal_session.backlog_since(delivered_output_seq) {
                                if !terminal_session.is_current_attachment(attachment_id) {
                                    break;
                                }

                                delivered_output_seq = output.seq;
                            }

                            if send_encrypted_json(
                                &mut socket,
                                session_cipher.as_ref(),
                                &TerminalSession::terminal_mode_payload(terminal_session.current_modes()),
                            )
                            .await
                            .is_err()
                            {
                                break;
                            }

                            let snapshot = terminal_session.current_display_snapshot();
                            let delta =
                                build_display_delta(last_display_snapshot.as_ref(), &snapshot);
                            last_display_snapshot = Some(snapshot);
                            if send_encrypted_json(
                                &mut socket,
                                session_cipher.as_ref(),
                                &TerminalSession::display_delta_payload(delta, None),
                            )
                            .await
                            .is_err()
                            {
                                break;
                            }
                        }
                    }
                }
            }
        }

        if !explicit_disconnect {
            terminal_session.mark_detached(attachment_id);
        }

        let _ = socket.close(None).await;
    });

    Ok(response)
}

impl Clone for AppState {
    fn clone(&self) -> Self {
        Self {
            access_token: Arc::clone(&self.access_token),
            sessions: Arc::clone(&self.sessions),
        }
    }
}

#[actix_web::main]
async fn main() -> std::io::Result<()> {
    env_logger::Builder::from_env(env_logger::Env::default().default_filter_or("info")).init();
    let app_config = load_app_config();
    let bind_addr = configured_bind_addr(&app_config.server);
    let bind_port = configured_bind_port(&bind_addr);
    let access_token = load_access_token(config_access_token(&app_config));
    if access_token.generated {
        log::warn!(
            "Access token is not set in config.json or REMOTE_CONTROL_ACCESS_TOKEN. Using default access token: {}",
            access_token.value
        );
    } else {
        log::info!("Access token loaded from config.json or environment.");
    }
    log::info!("Web clients must use an access token to connect.");

    log::info!("Starting remote control server at http://{}", bind_addr);
    log::info!("Open http://localhost:{} in your browser", bind_port);

    let app_state = web::Data::new(AppState {
        access_token: Arc::new(access_token.value),
        sessions: Arc::new(Mutex::new(HashMap::new())),
    });

    actix_web::rt::spawn(run_session_reaper(app_state.clone()));

    let server = HttpServer::new(move || {
        App::new()
            .app_data(app_state.clone())
            .wrap(middleware::Logger::default())
            .route("/", web::get().to(index))
            .route("/ws", web::get().to(ws_handler))
    })
    .bind(bind_addr.as_str())?;

    if let Some(config) =
        reverse_proxy::ReverseProxyConfig::from_sources(&app_config.reverse_proxy, bind_port)
    {
        reverse_proxy::spawn_client(config);
    }

    server.run().await
}

#[cfg(test)]
mod tests {
    use super::{
        configured_bind_port, decrypt_payload, default_cwd, derive_cipher, encrypt_payload,
        normalize_path, resolve_initial_cwd, terminal_shell, AppConfigFile, TerminalModeTracker,
    };
    use crate::terminal;

    #[cfg(windows)]
    #[test]
    fn normalizes_windows_file_url_paths() {
        assert_eq!(
            normalize_path("file:///C:/Program%20Files"),
            r"C:\Program Files"
        );
    }

    #[cfg(unix)]
    #[test]
    fn normalizes_unix_file_url_paths() {
        assert_eq!(
            normalize_path("file:///tmp/example%20dir"),
            "/tmp/example dir"
        );
    }

    #[test]
    fn leaves_plain_paths_unchanged() {
        assert_eq!(normalize_path(r"C:\Windows"), r"C:\Windows");
    }

    #[test]
    fn leaves_non_file_urls_unchanged() {
        assert_eq!(
            normalize_path("https://example.com/path"),
            "https://example.com/path"
        );
    }

    #[test]
    fn resolve_initial_cwd_accepts_existing_directories() {
        let cwd = default_cwd();
        assert_eq!(resolve_initial_cwd(Some(&cwd)), cwd);
    }

    #[test]
    fn resolve_initial_cwd_falls_back_for_missing_directories() {
        assert_eq!(
            resolve_initial_cwd(Some("__remote_control_missing_cwd_for_test__")),
            default_cwd()
        );
    }

    #[test]
    fn parses_config_file_shape() {
        let config: AppConfigFile = serde_json::from_str(
            r#"{
                "server": {
                    "bind_addr": "127.0.0.1:9090",
                    "access_token": "from-config"
                },
                "reverse_proxy": {
                    "enabled": true,
                    "server_host": "example.com",
                    "server_port": 7000,
                    "target_host": "127.0.0.1",
                    "target_port": 9090,
                    "psk": "proxy-psk",
                    "connect_timeout_secs": 1.5,
                    "retry_interval_secs": 2.5,
                    "heartbeat_interval_secs": 3.5,
                    "heartbeat_timeout_secs": 4.5
                }
            }"#,
        )
        .unwrap();

        assert_eq!(config.server.bind_addr.as_deref(), Some("127.0.0.1:9090"));
        assert_eq!(configured_bind_port("127.0.0.1:9090"), 9090);
        assert_eq!(config.server.access_token.as_deref(), Some("from-config"));
    }

    #[cfg(windows)]
    #[test]
    fn terminal_shell_uses_windows_powershell() {
        let shell = terminal_shell();
        assert_eq!(shell.program, "powershell.exe");
        assert!(shell.args.iter().any(|arg| arg == "-NoExit"));
    }

    #[cfg(unix)]
    #[test]
    fn terminal_shell_uses_unix_shell() {
        let shell = terminal_shell();
        assert!(!shell.program.trim().is_empty());
        assert!(shell.args.is_empty());
    }

    #[test]
    fn encrypted_payload_roundtrip_works() {
        let cipher = derive_cipher("test-access-token", b"0123456789abcdef").unwrap();
        let payload = terminal::ServerPayload::pong();
        let encrypted = encrypt_payload(&cipher, &payload).unwrap();
        let decrypted: terminal::ServerPayload = decrypt_payload(&cipher, &encrypted).unwrap();

        assert_eq!(decrypted.r#type, "pong");
        assert_eq!(decrypted.data, None);
        assert_eq!(decrypted.data_base64, None);
    }

    #[test]
    fn tracks_tui_terminal_modes_across_chunks() {
        let mut tracker = TerminalModeTracker::default();

        assert!(tracker.process(b"\x1b[?1049").is_empty());
        let changes = tracker.process(b";1000;1006;1007h");
        assert_eq!(changes.len(), 1);
        assert!(changes[0].alternate_screen);
        assert!(changes[0].mouse_tracking);
        assert!(changes[0].mouse_sgr);
        assert!(changes[0].alternate_scroll);

        let changes = tracker.process(b"\x1b[?1000l");
        assert_eq!(changes.len(), 1);
        assert!(changes[0].alternate_screen);
        assert!(!changes[0].mouse_tracking);
        assert!(changes[0].mouse_sgr);
        assert!(changes[0].alternate_scroll);

        let changes = tracker.process(b"\x1b[?1049;1006;1007l");
        assert_eq!(changes.len(), 1);
        assert!(!changes[0].alternate_screen);
        assert!(!changes[0].mouse_tracking);
        assert!(!changes[0].mouse_sgr);
        assert!(!changes[0].alternate_scroll);
    }
}
