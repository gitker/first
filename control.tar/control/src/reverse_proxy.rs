use hmac::{Hmac, Mac};
use rand::{rngs::OsRng, RngCore};
use serde::Deserialize;
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::env;
use std::io::{self, ErrorKind, Read, Write};
use std::net::{Shutdown, TcpStream, ToSocketAddrs};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::{Duration, Instant};

const MAGIC: &[u8; 4] = b"RPX1";
const NONCE_SIZE: usize = 16;
const PROOF_SIZE: usize = 32;
const TAG_SIZE: usize = 16;
const HEADER_SIZE: usize = 4;
const MAX_MESSAGE_SIZE: usize = 1024 * 1024;
const BUFFER_SIZE: usize = 64 * 1024;

const DEFAULT_SERVER_HOST: &str = "47.106.107.148";
const DEFAULT_SERVER_PORT: u16 = 7000;
const DEFAULT_TARGET_HOST: &str = "127.0.0.1";
const DEFAULT_PSK: &str = "your-strong-psk199029";
const DEFAULT_CONNECT_TIMEOUT_SECS: f64 = 5.0;
const DEFAULT_RETRY_INTERVAL_SECS: f64 = 3.0;
const DEFAULT_HEARTBEAT_INTERVAL_SECS: f64 = 15.0;
const DEFAULT_HEARTBEAT_TIMEOUT_SECS: f64 = 45.0;

type HmacSha256 = Hmac<Sha256>;
type ProxyResult<T> = Result<T, Box<dyn std::error::Error + Send + Sync>>;

#[derive(Clone, Debug)]
pub struct ReverseProxyConfig {
    server_host: String,
    server_port: u16,
    target_host: String,
    target_port: u16,
    psk: String,
    connect_timeout: Duration,
    retry_interval: Duration,
    heartbeat_interval: Duration,
    heartbeat_timeout: Duration,
}

#[derive(Clone, Debug, Default, Deserialize)]
pub struct ReverseProxyFileConfig {
    pub enabled: Option<bool>,
    pub server_host: Option<String>,
    pub server_port: Option<u16>,
    pub target_host: Option<String>,
    pub target_port: Option<u16>,
    pub psk: Option<String>,
    pub connect_timeout_secs: Option<f64>,
    pub retry_interval_secs: Option<f64>,
    pub heartbeat_interval_secs: Option<f64>,
    pub heartbeat_timeout_secs: Option<f64>,
}

impl ReverseProxyConfig {
    pub fn from_sources(
        file_config: &ReverseProxyFileConfig,
        default_target_port: u16,
    ) -> Option<Self> {
        let enabled = env_bool("REMOTE_PROXY_ENABLED", file_config.enabled.unwrap_or(true));
        if !enabled {
            log::info!("Reverse proxy client disabled by configuration.");
            return None;
        }

        let heartbeat_interval = env_duration_secs(
            "REMOTE_PROXY_HEARTBEAT_INTERVAL",
            file_config
                .heartbeat_interval_secs
                .unwrap_or(DEFAULT_HEARTBEAT_INTERVAL_SECS),
        );
        let mut heartbeat_timeout = env_duration_secs(
            "REMOTE_PROXY_HEARTBEAT_TIMEOUT",
            file_config
                .heartbeat_timeout_secs
                .unwrap_or(DEFAULT_HEARTBEAT_TIMEOUT_SECS),
        );
        if heartbeat_enabled(heartbeat_interval, heartbeat_timeout)
            && heartbeat_timeout < heartbeat_interval
        {
            log::warn!(
                "REMOTE_PROXY_HEARTBEAT_TIMEOUT is less than interval; using interval as timeout"
            );
            heartbeat_timeout = heartbeat_interval;
        }

        Some(Self {
            server_host: env_string(
                "REMOTE_PROXY_SERVER_HOST",
                file_config
                    .server_host
                    .as_deref()
                    .unwrap_or(DEFAULT_SERVER_HOST),
            ),
            server_port: env_u16(
                "REMOTE_PROXY_SERVER_PORT",
                file_config.server_port.unwrap_or(DEFAULT_SERVER_PORT),
            ),
            target_host: env_string(
                "REMOTE_PROXY_TARGET_HOST",
                file_config
                    .target_host
                    .as_deref()
                    .unwrap_or(DEFAULT_TARGET_HOST),
            ),
            target_port: env_u16(
                "REMOTE_PROXY_TARGET_PORT",
                file_config.target_port.unwrap_or(default_target_port),
            ),
            psk: env_string(
                "REMOTE_PROXY_PSK",
                file_config.psk.as_deref().unwrap_or(DEFAULT_PSK),
            ),
            connect_timeout: env_duration_secs(
                "REMOTE_PROXY_CONNECT_TIMEOUT",
                file_config
                    .connect_timeout_secs
                    .unwrap_or(DEFAULT_CONNECT_TIMEOUT_SECS),
            ),
            retry_interval: env_duration_secs(
                "REMOTE_PROXY_RETRY_INTERVAL",
                file_config
                    .retry_interval_secs
                    .unwrap_or(DEFAULT_RETRY_INTERVAL_SECS),
            ),
            heartbeat_interval,
            heartbeat_timeout,
        })
    }
}

pub fn spawn_client(config: ReverseProxyConfig) {
    let thread_name = "reverse-proxy-client";
    match thread::Builder::new()
        .name(thread_name.to_owned())
        .spawn(move || run_client(config))
    {
        Ok(_) => {}
        Err(error) => log::error!("Failed to start reverse proxy client thread: {}", error),
    }
}

fn run_client(config: ReverseProxyConfig) {
    loop {
        match connect_and_register(&config).and_then(|channel| {
            control_loop(Arc::clone(&channel), &config)?;
            channel.close();
            Ok(())
        }) {
            Ok(()) => {
                log::warn!("Reverse proxy control loop ended; reconnecting.");
            }
            Err(error) => {
                log::warn!("Reverse proxy reconnect after error: {}", error);
            }
        }

        thread::sleep(config.retry_interval);
    }
}

fn connect_and_register(config: &ReverseProxyConfig) -> ProxyResult<Arc<SecureChannel>> {
    let channel = connect_secure_channel(&config.server_host, config.server_port, &config.psk)?;
    send_json(
        &channel,
        &json!({
            "type": "control",
            "target_host": config.target_host,
            "target_port": config.target_port,
        }),
    )?;

    let response = recv_json(&channel, false)?;
    match response {
        ChannelJson::Message(message)
            if message.get("type").and_then(Value::as_str) == Some("ok") =>
        {
            log::info!(
                "Reverse proxy registered target {}:{} -> {}:{}",
                config.target_host,
                config.target_port,
                message
                    .get("public_host")
                    .and_then(Value::as_str)
                    .unwrap_or("?"),
                message
                    .get("public_port")
                    .and_then(Value::as_i64)
                    .map(|port| port.to_string())
                    .unwrap_or_else(|| "?".to_owned())
            );
            Ok(channel)
        }
        ChannelJson::Message(_) => {
            channel.close();
            proxy_error("server rejected control registration")
        }
        ChannelJson::Closed => {
            channel.close();
            proxy_error("server closed during control registration")
        }
        ChannelJson::Timeout => {
            channel.close();
            proxy_error("timed out during control registration")
        }
    }
}

fn control_loop(channel: Arc<SecureChannel>, config: &ReverseProxyConfig) -> ProxyResult<()> {
    if !heartbeat_enabled(config.heartbeat_interval, config.heartbeat_timeout) {
        loop {
            match recv_json(&channel, false)? {
                ChannelJson::Message(message) => handle_control_message(&channel, config, message)?,
                ChannelJson::Closed => return proxy_error("control channel closed"),
                ChannelJson::Timeout => {}
            }
        }
    }

    let read_timeout = config.heartbeat_interval.min(config.heartbeat_timeout);
    channel.set_read_timeout(Some(read_timeout))?;

    let mut last_recv = Instant::now();
    let mut last_ping = last_recv
        .checked_sub(config.heartbeat_interval)
        .unwrap_or(last_recv);

    let result = loop {
        let now = Instant::now();
        if now.duration_since(last_ping) >= config.heartbeat_interval {
            send_json(&channel, &json!({ "type": "ping" }))?;
            last_ping = now;
        }

        match recv_json(&channel, true)? {
            ChannelJson::Message(message) => {
                last_recv = Instant::now();
                handle_control_message(&channel, config, message)?;
            }
            ChannelJson::Closed => break proxy_error("control channel closed"),
            ChannelJson::Timeout => {
                if Instant::now().duration_since(last_recv) >= config.heartbeat_timeout {
                    break proxy_error("control channel heartbeat timed out");
                }
            }
        }
    };

    let _ = channel.set_read_timeout(None);
    result
}

fn handle_control_message(
    channel: &Arc<SecureChannel>,
    config: &ReverseProxyConfig,
    message: Value,
) -> ProxyResult<()> {
    match message.get("type").and_then(Value::as_str) {
        Some("open") => {
            let stream_id = message
                .get("stream_id")
                .and_then(Value::as_str)
                .ok_or_else(|| other_error("open request missing stream_id"))?
                .to_owned();
            let channel = Arc::clone(channel);
            let config = config.clone();
            thread::spawn(move || handle_open_request(channel, config, stream_id));
            Ok(())
        }
        Some("ping") => send_json(channel, &json!({ "type": "pong" })),
        Some("pong") => Ok(()),
        Some(message_type) => proxy_error(format!("unknown control command: {}", message_type)),
        None => proxy_error("control command missing type"),
    }
}

fn handle_open_request(
    control_channel: Arc<SecureChannel>,
    config: ReverseProxyConfig,
    stream_id: String,
) {
    match open_local_and_data_channel(&config, &stream_id) {
        Ok((local_sock, data_channel)) => {
            log::info!(
                "Reverse proxy attached local target for stream {}",
                stream_id
            );
            bridge_socket_and_channel(
                local_sock,
                data_channel,
                format!("client-stream-{}", stream_id),
            );
        }
        Err(error) => {
            log::warn!(
                "Reverse proxy failed to open stream {}: {}",
                stream_id,
                error
            );
            send_open_failed(&control_channel, &stream_id, &error.to_string());
        }
    }
}

fn open_local_and_data_channel(
    config: &ReverseProxyConfig,
    stream_id: &str,
) -> ProxyResult<(TcpStream, Arc<SecureChannel>)> {
    let local_sock = connect_local_target(config)?;
    let data_channel =
        connect_secure_channel(&config.server_host, config.server_port, &config.psk)?;
    send_json(
        &data_channel,
        &json!({
            "type": "data",
            "stream_id": stream_id,
        }),
    )?;

    match recv_json(&data_channel, false)? {
        ChannelJson::Message(message)
            if message.get("type").and_then(Value::as_str) == Some("ok") =>
        {
            Ok((local_sock, data_channel))
        }
        ChannelJson::Message(message) => {
            data_channel.close();
            let message = message
                .get("message")
                .and_then(Value::as_str)
                .unwrap_or("server rejected stream");
            proxy_error(message)
        }
        ChannelJson::Closed => {
            data_channel.close();
            proxy_error("server closed data channel")
        }
        ChannelJson::Timeout => {
            data_channel.close();
            proxy_error("timed out waiting for data channel confirmation")
        }
    }
}

fn connect_local_target(config: &ReverseProxyConfig) -> ProxyResult<TcpStream> {
    let mut last_error = None;
    let addresses = (config.target_host.as_str(), config.target_port).to_socket_addrs()?;
    for address in addresses {
        let result = if config.connect_timeout.is_zero() {
            TcpStream::connect(address)
        } else {
            TcpStream::connect_timeout(&address, config.connect_timeout)
        };

        match result {
            Ok(stream) => {
                stream.set_read_timeout(None)?;
                stream.set_write_timeout(None)?;
                return Ok(stream);
            }
            Err(error) => last_error = Some(error),
        }
    }

    let error = last_error.unwrap_or_else(|| other_error("target host resolved to no addresses"));
    Err(Box::new(error))
}

fn send_open_failed(control_channel: &SecureChannel, stream_id: &str, error: &str) {
    let _ = send_json(
        control_channel,
        &json!({
            "type": "open_failed",
            "stream_id": stream_id,
            "error": error,
        }),
    );
}

fn bridge_socket_and_channel(plain_sock: TcpStream, channel: Arc<SecureChannel>, label: String) {
    let plain_reader = match plain_sock.try_clone() {
        Ok(sock) => sock,
        Err(error) => {
            log::warn!("{} failed to clone local socket reader: {}", label, error);
            channel.close();
            return;
        }
    };
    let plain_writer = match plain_sock.try_clone() {
        Ok(sock) => sock,
        Err(error) => {
            log::warn!("{} failed to clone local socket writer: {}", label, error);
            channel.close();
            return;
        }
    };

    let channel_for_input = Arc::clone(&channel);
    let input_label = label.clone();
    let input_thread = thread::spawn(move || {
        let mut plain_reader = plain_reader;
        let mut buf = [0u8; BUFFER_SIZE];
        loop {
            match plain_reader.read(&mut buf) {
                Ok(0) => {
                    let _ = channel_for_input.send_message(b"E");
                    break;
                }
                Ok(n) => {
                    let mut message = Vec::with_capacity(n + 1);
                    message.push(b'D');
                    message.extend_from_slice(&buf[..n]);
                    if let Err(error) = channel_for_input.send_message(&message) {
                        log::debug!("{} plain_to_channel stopped: {}", input_label, error);
                        channel_for_input.close();
                        break;
                    }
                }
                Err(error) => {
                    log::debug!("{} plain_to_channel stopped: {}", input_label, error);
                    channel_for_input.close();
                    break;
                }
            }
        }
    });

    let channel_for_output = Arc::clone(&channel);
    let output_label = label.clone();
    let output_thread = thread::spawn(move || {
        let mut plain_writer = plain_writer;
        loop {
            match channel_for_output.recv_message(false) {
                Ok(ChannelMessage::Message(message)) => {
                    if message.is_empty() {
                        continue;
                    }
                    match message[0] {
                        b'D' => {
                            if let Err(error) = plain_writer.write_all(&message[1..]) {
                                log::debug!("{} channel_to_plain stopped: {}", output_label, error);
                                break;
                            }
                        }
                        b'E' => {
                            let _ = plain_writer.shutdown(Shutdown::Write);
                            break;
                        }
                        _ => {
                            log::debug!("{} unknown stream message type", output_label);
                            break;
                        }
                    }
                }
                Ok(ChannelMessage::Closed) => break,
                Ok(ChannelMessage::Timeout) => {}
                Err(error) => {
                    log::debug!("{} channel_to_plain stopped: {}", output_label, error);
                    break;
                }
            }
        }
    });

    let _ = input_thread.join();
    let _ = output_thread.join();
    channel.close();
    let _ = plain_sock.shutdown(Shutdown::Both);
}

fn connect_secure_channel(host: &str, port: u16, psk: &str) -> ProxyResult<Arc<SecureChannel>> {
    let sock = TcpStream::connect((host, port))?;
    client_handshake(sock, psk)
}

fn client_handshake(mut sock: TcpStream, psk: &str) -> ProxyResult<Arc<SecureChannel>> {
    let mut client_nonce = [0u8; NONCE_SIZE];
    OsRng.fill_bytes(&mut client_nonce);

    sock.write_all(MAGIC)?;
    sock.write_all(&client_nonce)?;

    let mut hello = [0u8; HEADER_SIZE + NONCE_SIZE];
    recv_exact(&mut sock, &mut hello)?;
    if &hello[..HEADER_SIZE] != MAGIC {
        return proxy_error("invalid server hello");
    }
    let server_nonce: [u8; NONCE_SIZE] = hello[HEADER_SIZE..].try_into()?;

    let keys = derive_session_keys(psk, &client_nonce, &server_nonce);
    let client_proof = proof_for(&keys.auth, b"client", &client_nonce, &server_nonce);
    sock.write_all(&client_proof)?;

    let mut server_proof = [0u8; PROOF_SIZE];
    recv_exact(&mut sock, &mut server_proof)?;
    let expected = proof_for(&keys.auth, b"server", &client_nonce, &server_nonce);
    if !constant_time_eq(&server_proof, &expected) {
        return proxy_error("server proof verification failed");
    }

    SecureChannel::new(sock, keys.c2s_enc, keys.c2s_mac, keys.s2c_enc, keys.s2c_mac).map(Arc::new)
}

fn recv_exact(sock: &mut TcpStream, buf: &mut [u8]) -> ProxyResult<()> {
    let mut offset = 0;
    while offset < buf.len() {
        let n = sock.read(&mut buf[offset..])?;
        if n == 0 {
            return proxy_error("socket closed during read");
        }
        offset += n;
    }
    Ok(())
}

struct SessionKeys {
    auth: [u8; 32],
    c2s_enc: [u8; 32],
    c2s_mac: [u8; 32],
    s2c_enc: [u8; 32],
    s2c_mac: [u8; 32],
}

fn derive_session_keys(
    psk: &str,
    client_nonce: &[u8; NONCE_SIZE],
    server_nonce: &[u8; NONCE_SIZE],
) -> SessionKeys {
    let psk_material = Sha256::digest(psk.as_bytes());
    let seed = hmac_sha256(&psk_material, &[b"seed", client_nonce, server_nonce]);

    SessionKeys {
        auth: hmac_sha256(&seed, &[b"auth", client_nonce, server_nonce]),
        c2s_enc: hmac_sha256(&seed, &[b"c2s_enc", client_nonce, server_nonce]),
        c2s_mac: hmac_sha256(&seed, &[b"c2s_mac", client_nonce, server_nonce]),
        s2c_enc: hmac_sha256(&seed, &[b"s2c_enc", client_nonce, server_nonce]),
        s2c_mac: hmac_sha256(&seed, &[b"s2c_mac", client_nonce, server_nonce]),
    }
}

fn proof_for(
    auth_key: &[u8; 32],
    label: &[u8],
    client_nonce: &[u8; NONCE_SIZE],
    server_nonce: &[u8; NONCE_SIZE],
) -> [u8; PROOF_SIZE] {
    hmac_sha256(auth_key, &[label, client_nonce, server_nonce])
}

fn hmac_sha256(key: &[u8], parts: &[&[u8]]) -> [u8; 32] {
    let mut mac = HmacSha256::new_from_slice(key).expect("HMAC-SHA256 accepts any key length");
    for part in parts {
        mac.update(part);
    }
    let bytes = mac.finalize().into_bytes();
    bytes.into()
}

fn xor_stream(key: &[u8; 32], seq: u64, payload: &[u8]) -> Vec<u8> {
    let seq_bytes = seq.to_be_bytes();
    let mut out = Vec::with_capacity(payload.len());
    let mut counter = 0u32;
    let mut offset = 0;

    while offset < payload.len() {
        let counter_bytes = counter.to_be_bytes();
        let block = hmac_sha256(key, &[&seq_bytes, &counter_bytes]);
        let block_len = block.len().min(payload.len() - offset);
        for i in 0..block_len {
            out.push(payload[offset + i] ^ block[i]);
        }
        offset += block_len;
        counter += 1;
    }

    out
}

struct SecureChannel {
    send_enc_key: [u8; 32],
    send_mac_key: [u8; 32],
    recv_enc_key: [u8; 32],
    recv_mac_key: [u8; 32],
    send: Mutex<SendState>,
    recv: Mutex<RecvState>,
    close_stream: TcpStream,
    closed: AtomicBool,
}

struct SendState {
    stream: TcpStream,
    seq: u64,
}

struct RecvState {
    stream: TcpStream,
    seq: u64,
    buffer: Vec<u8>,
}

enum ChannelMessage {
    Message(Vec<u8>),
    Timeout,
    Closed,
}

impl SecureChannel {
    fn new(
        sock: TcpStream,
        send_enc_key: [u8; 32],
        send_mac_key: [u8; 32],
        recv_enc_key: [u8; 32],
        recv_mac_key: [u8; 32],
    ) -> ProxyResult<Self> {
        let send_stream = sock.try_clone()?;
        let recv_stream = sock.try_clone()?;

        Ok(Self {
            send_enc_key,
            send_mac_key,
            recv_enc_key,
            recv_mac_key,
            send: Mutex::new(SendState {
                stream: send_stream,
                seq: 0,
            }),
            recv: Mutex::new(RecvState {
                stream: recv_stream,
                seq: 0,
                buffer: Vec::new(),
            }),
            close_stream: sock,
            closed: AtomicBool::new(false),
        })
    }

    fn send_message(&self, payload: &[u8]) -> ProxyResult<()> {
        if self.closed.load(Ordering::SeqCst) {
            return proxy_error("channel closed");
        }
        if payload.len() > MAX_MESSAGE_SIZE {
            return proxy_error("message too large");
        }

        let mut send = self
            .send
            .lock()
            .map_err(|_| other_error("channel send lock poisoned"))?;
        if self.closed.load(Ordering::SeqCst) {
            return proxy_error("channel closed");
        }

        let ciphertext = xor_stream(&self.send_enc_key, send.seq, payload);
        let length_bytes = (ciphertext.len() as u32).to_be_bytes();
        let seq_bytes = send.seq.to_be_bytes();
        let tag = hmac_sha256(
            &self.send_mac_key,
            &[&seq_bytes, &length_bytes, &ciphertext],
        );

        send.stream.write_all(&length_bytes)?;
        send.stream.write_all(&tag[..TAG_SIZE])?;
        send.stream.write_all(&ciphertext)?;
        send.seq += 1;
        Ok(())
    }

    fn recv_message(&self, allow_timeout: bool) -> ProxyResult<ChannelMessage> {
        let mut recv = self
            .recv
            .lock()
            .map_err(|_| other_error("channel recv lock poisoned"))?;

        loop {
            if recv.buffer.len() >= HEADER_SIZE + TAG_SIZE {
                let length = u32::from_be_bytes(recv.buffer[..HEADER_SIZE].try_into()?) as usize;
                if length > MAX_MESSAGE_SIZE {
                    return proxy_error("message too large");
                }

                let frame_size = HEADER_SIZE + TAG_SIZE + length;
                if recv.buffer.len() >= frame_size {
                    let tag_start = HEADER_SIZE;
                    let data_start = tag_start + TAG_SIZE;
                    let header = recv.buffer[..HEADER_SIZE].to_vec();
                    let tag = recv.buffer[tag_start..data_start].to_vec();
                    let ciphertext = recv.buffer[data_start..frame_size].to_vec();
                    recv.buffer.drain(..frame_size);

                    let seq_bytes = recv.seq.to_be_bytes();
                    let expected =
                        hmac_sha256(&self.recv_mac_key, &[&seq_bytes, &header, &ciphertext]);
                    if !constant_time_eq(&tag, &expected[..TAG_SIZE]) {
                        return proxy_error("message authentication failed");
                    }

                    let payload = xor_stream(&self.recv_enc_key, recv.seq, &ciphertext);
                    recv.seq += 1;
                    return Ok(ChannelMessage::Message(payload));
                }
            }

            let mut buf = [0u8; BUFFER_SIZE];
            match recv.stream.read(&mut buf) {
                Ok(0) => return Ok(ChannelMessage::Closed),
                Ok(n) => recv.buffer.extend_from_slice(&buf[..n]),
                Err(error)
                    if allow_timeout
                        && matches!(error.kind(), ErrorKind::WouldBlock | ErrorKind::TimedOut) =>
                {
                    return Ok(ChannelMessage::Timeout)
                }
                Err(error) => return Err(Box::new(error)),
            }
        }
    }

    fn set_read_timeout(&self, timeout: Option<Duration>) -> io::Result<()> {
        let recv = self
            .recv
            .lock()
            .map_err(|_| other_error("channel recv lock poisoned"))?;
        recv.stream.set_read_timeout(timeout)
    }

    fn close(&self) {
        if self.closed.swap(true, Ordering::SeqCst) {
            return;
        }
        let _ = self.close_stream.shutdown(Shutdown::Both);
    }
}

enum ChannelJson {
    Message(Value),
    Timeout,
    Closed,
}

fn send_json(channel: &SecureChannel, payload: &Value) -> ProxyResult<()> {
    let bytes = serde_json::to_vec(payload)?;
    channel.send_message(&bytes)
}

fn recv_json(channel: &SecureChannel, allow_timeout: bool) -> ProxyResult<ChannelJson> {
    match channel.recv_message(allow_timeout)? {
        ChannelMessage::Message(payload) => {
            Ok(ChannelJson::Message(serde_json::from_slice(&payload)?))
        }
        ChannelMessage::Timeout => Ok(ChannelJson::Timeout),
        ChannelMessage::Closed => Ok(ChannelJson::Closed),
    }
}

fn heartbeat_enabled(interval: Duration, timeout: Duration) -> bool {
    !interval.is_zero() && !timeout.is_zero()
}

fn env_string(key: &str, default: &str) -> String {
    env::var(key)
        .ok()
        .map(|value| value.trim().to_owned())
        .filter(|value| !value.is_empty())
        .unwrap_or_else(|| default.to_owned())
}

fn env_bool(key: &str, default: bool) -> bool {
    env::var(key)
        .ok()
        .map(|value| {
            let value = value.trim().to_ascii_lowercase();
            !matches!(value.as_str(), "0" | "false" | "off" | "no")
        })
        .unwrap_or(default)
}

fn env_u16(key: &str, default: u16) -> u16 {
    env::var(key)
        .ok()
        .and_then(|value| value.trim().parse::<u16>().ok())
        .unwrap_or(default)
}

fn env_duration_secs(key: &str, default: f64) -> Duration {
    let secs = env::var(key)
        .ok()
        .and_then(|value| value.trim().parse::<f64>().ok())
        .filter(|value| value.is_finite() && *value >= 0.0)
        .unwrap_or(default);
    Duration::from_secs_f64(secs)
}

fn constant_time_eq(left: &[u8], right: &[u8]) -> bool {
    if left.len() != right.len() {
        return false;
    }

    let mut diff = 0u8;
    for (a, b) in left.iter().zip(right.iter()) {
        diff |= a ^ b;
    }
    diff == 0
}

fn proxy_error<T>(message: impl Into<String>) -> ProxyResult<T> {
    Err(Box::new(other_error(message)))
}

fn other_error(message: impl Into<String>) -> io::Error {
    io::Error::new(ErrorKind::Other, message.into())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn xor_stream_roundtrip_works() {
        let key = [7u8; 32];
        let payload = b"hello reverse proxy";
        let encrypted = xor_stream(&key, 42, payload);
        assert_ne!(encrypted, payload);
        assert_eq!(xor_stream(&key, 42, &encrypted), payload);
    }

    #[test]
    fn constant_time_eq_checks_content_and_length() {
        assert!(constant_time_eq(b"abc", b"abc"));
        assert!(!constant_time_eq(b"abc", b"abd"));
        assert!(!constant_time_eq(b"abc", b"abcd"));
    }

    #[test]
    fn key_derivation_matches_python_proxy_vector() {
        let client_nonce = bytes_0_to_15();
        let server_nonce = bytes_16_to_31();
        let keys = derive_session_keys("test-psk", &client_nonce, &server_nonce);

        assert_eq!(
            keys.auth,
            hex_32("72528906edd81a4642470fc2ff3efcd50321e85483d47a64cd96ca469ed1fcf5")
        );
        assert_eq!(
            keys.c2s_enc,
            hex_32("8d4cf3336d03837a15f23184f0c4feb373ace9a225ac75422317f63911eca44d")
        );
        assert_eq!(
            keys.c2s_mac,
            hex_32("9e1ff597c6425a02a3c40dff275bec19ae9fb10b432920bb82c2aafd2e723dba")
        );
        assert_eq!(
            proof_for(&keys.auth, b"client", &client_nonce, &server_nonce),
            hex_32("ce43efeb85669c33e0cbca858a4bc15c6c01e566a85a53a4d05723366591f192")
        );
        assert_eq!(
            proof_for(&keys.auth, b"server", &client_nonce, &server_nonce),
            hex_32("e1bf8f8a20b39530a9f6590c32404cba975024f675571f4174d2d6b707a157d0")
        );
    }

    #[test]
    fn frame_cipher_and_tag_match_python_proxy_vector() {
        let client_nonce = bytes_0_to_15();
        let server_nonce = bytes_16_to_31();
        let keys = derive_session_keys("test-psk", &client_nonce, &server_nonce);
        let payload = b"abc";
        let ciphertext = xor_stream(&keys.c2s_enc, 0, payload);
        let length_bytes = (ciphertext.len() as u32).to_be_bytes();
        let tag = hmac_sha256(
            &keys.c2s_mac,
            &[&0u64.to_be_bytes(), &length_bytes, &ciphertext],
        );

        assert_eq!(ciphertext, vec![0xec, 0xbd, 0x3e]);
        assert_eq!(
            &tag[..TAG_SIZE],
            &[
                0x97, 0xea, 0x7b, 0xdb, 0xd1, 0x6e, 0xf3, 0xb8, 0x24, 0x51, 0xcf, 0xd6, 0xea, 0x47,
                0xdf, 0x5c
            ]
        );
    }

    fn bytes_0_to_15() -> [u8; NONCE_SIZE] {
        let mut bytes = [0u8; NONCE_SIZE];
        for (index, byte) in bytes.iter_mut().enumerate() {
            *byte = index as u8;
        }
        bytes
    }

    fn bytes_16_to_31() -> [u8; NONCE_SIZE] {
        let mut bytes = [0u8; NONCE_SIZE];
        for (index, byte) in bytes.iter_mut().enumerate() {
            *byte = (index + 16) as u8;
        }
        bytes
    }

    fn hex_32(input: &str) -> [u8; 32] {
        assert_eq!(input.len(), 64);
        let mut output = [0u8; 32];
        for (index, slot) in output.iter_mut().enumerate() {
            *slot = u8::from_str_radix(&input[index * 2..index * 2 + 2], 16).unwrap();
        }
        output
    }
}
